<?php
/**
 * TalentSprint storage layer.
 *
 * Uses a JSON datastore so the portal can run without the mysqli extension.
 * MySQL credentials are retained for reference if MySQL is enabled later.
 */

const DB_HOST = 'db01.dbhost.dev';
const DB_PORT = 5051;
const DB_NAME = 'db_452hrdayt';
const DB_USER = 'user_452hrdayt';
const DB_PASS = 'p452hrdayt';

define('DATA_DIR', dirname(__DIR__, 2) . '/talentsprint_data');
define('DATA_FILE', DATA_DIR . '/portal.json');

/**
 * Return the default database structure.
 */
function db_default(): array
{
    return [
        'users' => [],
        'students' => [],
        'companies' => [],
        'internships' => [],
        'applications' => [],
        'counters' => [
            'users' => 0,
            'students' => 0,
            'companies' => 0,
            'internships' => 0,
            'applications' => 0,
        ],
    ];
}

/**
 * Create the storage directory and JSON file if necessary.
 */
function db_boot(): void
{
    if (!is_dir(DATA_DIR)) {
        @mkdir(DATA_DIR, 0775, true);
    }

    if (!file_exists(DATA_FILE)) {
        @file_put_contents(
            DATA_FILE,
            json_encode(db_default(), JSON_PRETTY_PRINT),
            LOCK_EX
        );
    }
}

/**
 * Load and validate the stored data.
 */
function db_load(): array
{
    db_boot();

    $raw = @file_get_contents(DATA_FILE);

    $data = ($raw !== false && $raw !== '')
        ? json_decode($raw, true)
        : null;

    if (!is_array($data)) {
        $data = db_default();
    }

    foreach (db_default() as $key => $defaultValue) {
        if (
            !array_key_exists($key, $data)
            || !is_array($data[$key])
        ) {
            $data[$key] = $defaultValue;
        }
    }

    return $data;
}

/**
 * Save data to the JSON datastore.
 */
function db_save(array $data): bool
{
    db_boot();

    $tmp = DATA_FILE . '.tmp';

    $json = json_encode(
        $data,
        JSON_PRETTY_PRINT
        | JSON_UNESCAPED_UNICODE
        | JSON_UNESCAPED_SLASHES
    );

    if ($json === false) {
        return false;
    }

    if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
        return false;
    }

    return @rename($tmp, DATA_FILE);
}

/**
 * Generate the next ID for a table.
 */
function db_next_id(array &$data, string $table): int
{
    $data['counters'][$table] =
        (int) ($data['counters'][$table] ?? 0) + 1;

    return $data['counters'][$table];
}

/**
 * Return the current timestamp.
 */
function db_now(): string
{
    return date('Y-m-d H:i:s');
}

/**
 * Find a user by email address.
 */
function db_find_user_by_email(
    array $data,
    string $email
): ?array {
    foreach ($data['users'] as $user) {
        if (
            is_array($user)
            && strcasecmp(
                (string) ($user['email'] ?? ''),
                $email
            ) === 0
        ) {
            return $user;
        }
    }

    return null;
}

/**
 * Find a user by ID.
 */
function db_user(array $data, int $id): ?array
{
    foreach ($data['users'] as $user) {
        if (
            is_array($user)
            && (int) ($user['id'] ?? 0) === $id
        ) {
            return $user;
        }
    }

    return null;
}

/**
 * Find a student profile by user ID.
 */
function db_student_by_user(
    array $data,
    int $userId
): ?array {
    foreach ($data['students'] as $row) {
        if (
            is_array($row)
            && (int) ($row['user_id'] ?? 0) === $userId
        ) {
            return $row;
        }
    }

    return null;
}

/**
 * Find a company profile by user ID.
 */
function db_company_by_user(
    array $data,
    int $userId
): ?array {
    foreach ($data['companies'] as $row) {
        if (
            is_array($row)
            && (int) ($row['user_id'] ?? 0) === $userId
        ) {
            return $row;
        }
    }

    return null;
}

/**
 * Find a company by ID.
 */
function db_company(array $data, int $id): ?array
{
    foreach ($data['companies'] as $row) {
        if (
            is_array($row)
            && (int) ($row['id'] ?? 0) === $id
        ) {
            return $row;
        }
    }

    return null;
}

/**
 * Find an internship by ID.
 */
function db_internship(array $data, int $id): ?array
{
    foreach ($data['internships'] as $row) {
        if (
            is_array($row)
            && (int) ($row['id'] ?? 0) === $id
        ) {
            return $row;
        }
    }

    return null;
}

/**
 * Sort records from newest to oldest.
 */
function db_sort_newest(
    array &$rows,
    string $field = 'created_at'
): void {
    usort(
        $rows,
        static function (array $a, array $b) use ($field): int {
            return strcmp(
                (string) ($b[$field] ?? ''),
                (string) ($a[$field] ?? '')
            );
        }
    );
}

/**
 * Escape a value for safe HTML output.
 */
function e(mixed $value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

/**
 * Store a temporary flash message.
 */
function flash(string $type, string $message): void
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message,
    ];
}

/**
 * Retrieve and remove a temporary flash message.
 */
function take_flash(): ?array
{
    $flash = $_SESSION['flash'] ?? null;

    unset($_SESSION['flash']);

    return is_array($flash) ? $flash : null;
}

/**
 * Ensure the current user has the required role.
 */
function require_role(
    string $role,
    string $loginPath = '../login.php'
): void {
    if (
        !isset($_SESSION['user_id'])
        || ($_SESSION['role'] ?? '') !== $role
    ) {
        header('Location: ' . $loginPath);
        exit;
    }
}

/**
 * Convert a status into a CSS class.
 */
function status_class(string $status): string
{
    return strtolower(str_replace(' ', '-', $status));
}
?>
