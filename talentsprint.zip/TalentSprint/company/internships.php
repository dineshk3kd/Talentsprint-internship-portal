<?php
session_start();

require_once __DIR__ . '/../config/database.php';

require_role('company');

$data = db_load();
$company = db_company_by_user($data, (int) $_SESSION['user_id']);
$cid = (int) ($company['id'] ?? 0);

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) ($_POST['internship_id'] ?? 0);
    $action = $_POST['action'] ?? '';

    foreach ($data['internships'] as &$i) {
        if ((int) $i['id'] === $id && (int) $i['company_id'] === $cid) {
            if ($action === 'toggle') {
                $i['status'] = $i['status'] === 'Open' ? 'Closed' : 'Open';
            }
        }
    }

    unset($i);

    if (db_save($data)) {
        $message = 'Internship status updated.';
    }
}

$rows = [];

foreach ($data['internships'] as $i) {
    if ((int) $i['company_id'] === $cid) {
        $i['applicant_count'] = count(array_filter(
            $data['applications'],
            fn($a) => (int) $a['internship_id'] === (int) $i['id']
        ));

        $rows[] = $i;
    }
}

db_sort_newest($rows);
$flash = take_flash();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>My Internships · TalentSprint</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>
        /* ========================================
           TALENTSPRINT GALAXY TECH THEME
           Styles are contained in this PHP page.
        ======================================== */

        body {
            min-height: 100vh;
            overflow-x: hidden;
            color: #eef4ff !important;
            background:
                radial-gradient(ellipse at 10% 15%, rgba(99, 102, 241, .18), transparent 35%),
                radial-gradient(ellipse at 90% 75%, rgba(6, 182, 212, .13), transparent 35%),
                linear-gradient(135deg, #050816, #0a1025 52%, #15102e) !important;
        }

        /* Animated star field */
        body::before {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -2;
            pointer-events: none;
            opacity: .65;
            background-image:
                radial-gradient(2px 2px at 10% 20%, #67e8f9 50%, transparent 100%),
                radial-gradient(2px 2px at 25% 65%, #ffffff 50%, transparent 100%),
                radial-gradient(2px 2px at 42% 35%, #c4b5fd 50%, transparent 100%),
                radial-gradient(2px 2px at 68% 16%, #ffffff 50%, transparent 100%),
                radial-gradient(2px 2px at 80% 75%, #67e8f9 50%, transparent 100%),
                radial-gradient(2px 2px at 92% 43%, #f0abfc 50%, transparent 100%);
            background-size: 270px 270px;
            animation: tsStarsDrift 25s linear infinite;
        }

        /* Moving circuit grid */
        body::after {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -1;
            pointer-events: none;
            background-image:
                linear-gradient(rgba(103, 232, 249, .035) 1px, transparent 1px),
                linear-gradient(90deg, rgba(103, 232, 249, .035) 1px, transparent 1px);
            background-size: 38px 38px;
            mask-image: linear-gradient(to bottom, black, transparent 90%);
            animation: tsGrid 24s linear infinite;
        }

        @keyframes tsStarsDrift {
            from { background-position: 0 0; }
            to   { background-position: 0 -270px; }
        }

        @keyframes tsGrid {
            from { background-position: 0 0; }
            to   { background-position: 38px 38px; }
        }

        /* Main dashboard */
        .dashboard {
            position: relative;
            z-index: 1;
            width: min(1250px, calc(100% - 42px));
            margin: 42px auto 70px;
            animation: tsEnter .8s ease both;
        }

        @keyframes tsEnter {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Page heading */
        .page-heading {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 25px;
            margin-bottom: 28px;
            padding: 30px;
            overflow: hidden;
            border: 1px solid rgba(103, 232, 249, .22);
            border-radius: 24px;
            background: linear-gradient(
                120deg,
                rgba(9, 25, 53, .95),
                rgba(26, 18, 58, .93)
            );
            box-shadow:
                0 22px 65px rgba(0, 0, 0, .22),
                inset 0 1px 0 rgba(255, 255, 255, .035);
        }

        .page-heading::before {
            content: "";
            position: absolute;
            top: 0;
            left: -40%;
            width: 35%;
            height: 2px;
            background: linear-gradient(
                90deg,
                transparent,
                #22d3ee,
                #a78bfa,
                #f0abfc,
                transparent
            );
            box-shadow: 0 0 18px #22d3ee;
            animation: tsScan 6s linear infinite;
        }

        .page-heading::after {
            content: "✦";
            position: absolute;
            top: 17px;
            right: 24%;
            color: rgba(103, 232, 249, .5);
            font-size: 24px;
            animation: tsTwinkle 2.5s ease-in-out infinite;
        }

        @keyframes tsScan {
            from { left: -40%; }
            to   { left: 110%; }
        }

        @keyframes tsTwinkle {
            0%, 100% { opacity: .3; transform: scale(.8) rotate(0deg); }
            50%      { opacity: 1; transform: scale(1.2) rotate(90deg); }
        }

        .page-heading .eyebrow {
            margin: 0 0 12px;
            color: #67e8f9;
            font-size: 11px;
            font-weight: 850;
            letter-spacing: 3px;
        }

        .page-heading h1 {
            margin: 0 0 12px;
            font-size: clamp(32px, 5vw, 46px);
            font-weight: 850;
            letter-spacing: -1.4px;
            line-height: 1.15;
            color: #fff;
            background: linear-gradient(
                100deg,
                #ffffff,
                #67e8f9,
                #a78bfa,
                #f0abfc
            );
            background-size: 250% auto;
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: tsGradient 8s linear infinite;
        }

        @keyframes tsGradient {
            to { background-position: 250% center; }
        }

        .page-heading > div > p:last-child {
            margin: 0;
            color: #a8b9d9;
            font-size: 14px;
            line-height: 1.7;
        }

        /* Add new internship button */
        .page-heading .btn.primary {
            position: relative;
            z-index: 1;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            padding: 14px 21px;
            border: 1px solid rgba(103, 232, 249, .35);
            border-radius: 13px;
            background: linear-gradient(110deg, #0891b2, #4f46e5, #9333ea);
            color: #fff;
            font-size: 13px;
            font-weight: 800;
            white-space: nowrap;
            box-shadow: 0 9px 28px rgba(79, 70, 229, .25);
            transition: transform .25s ease, box-shadow .25s ease, filter .25s ease;
        }

        .page-heading .btn.primary::before {
            content: "+";
            font-size: 20px;
            line-height: 1;
        }

        .page-heading .btn.primary:hover {
            transform: translateY(-3px);
            filter: brightness(1.15);
            box-shadow: 0 13px 32px rgba(34, 211, 238, .2);
        }

        /* Notifications */
        .alert.success {
            margin: 0 0 20px;
            padding: 15px 19px;
            border: 1px solid rgba(52, 211, 153, .35);
            border-radius: 13px;
            background: rgba(6, 95, 70, .2);
            color: #a7f3d0;
            box-shadow: 0 0 22px rgba(52, 211, 153, .06);
            animation: tsEnter .4s ease both;
        }

        /* Table container */
        .table-card {
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(103, 232, 249, .2);
            border-radius: 22px;
            background: rgba(8, 15, 36, .93);
            box-shadow:
                0 24px 70px rgba(0, 0, 0, .25),
                inset 0 1px 0 rgba(255, 255, 255, .035);
            backdrop-filter: blur(14px);
        }

        .table-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(
                90deg,
                #22d3ee,
                #6366f1,
                #d946ef,
                #22d3ee
            );
            background-size: 200% 100%;
            animation: tsBorder 5s linear infinite;
        }

        @keyframes tsBorder {
            to { background-position: 200% 0; }
        }

        .table-card table {
            width: 100%;
            border-collapse: collapse;
            color: #e6edff;
        }

        .table-card thead {
            background: linear-gradient(
                90deg,
                rgba(8, 145, 178, .18),
                rgba(99, 102, 241, .15),
                rgba(147, 51, 234, .14)
            );
        }

        .table-card th {
            padding: 19px 20px;
            border-bottom: 1px solid rgba(103, 232, 249, .17);
            color: #8eeaff;
            font-size: 11px;
            font-weight: 850;
            letter-spacing: 1.2px;
            text-align: left;
            text-transform: uppercase;
            white-space: nowrap;
        }

        .table-card td {
            padding: 20px;
            border-bottom: 1px solid rgba(148, 163, 255, .1);
            color: #cbd7f1;
            font-size: 13px;
            line-height: 1.7;
            vertical-align: middle;
            transition: background .25s ease;
        }

        .table-card tbody tr {
            transition: background .25s ease, box-shadow .25s ease;
        }

        .table-card tbody tr:hover {
            background: rgba(34, 211, 238, .055);
            box-shadow: inset 3px 0 0 #22d3ee;
        }

        .table-card tbody tr:last-child td {
            border-bottom: none;
        }

        .table-card td strong {
            color: #f3f7ff;
            font-size: 14px;
            font-weight: 750;
        }

        .table-card td small {
            color: #8c9fc4;
        }

        .table-card .empty {
            padding: 44px 20px;
            color: #9aabd0;
            text-align: center;
        }

        /* Open / Closed status labels */
        .table-card .status {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 7px 12px;
            border: 1px solid rgba(148, 163, 184, .25);
            border-radius: 999px;
            background: rgba(51, 65, 85, .25);
            color: #cbd5e1;
            font-size: 11px;
            font-weight: 800;
            white-space: nowrap;
        }

        .table-card .status::before {
            content: "";
            width: 7px;
            height: 7px;
            flex: 0 0 7px;
            border-radius: 50%;
            background: currentColor;
            box-shadow: 0 0 9px currentColor;
        }

        .table-card .status.open {
            color: #6ee7b7;
            border-color: rgba(52, 211, 153, .3);
            background: rgba(5, 150, 105, .13);
        }

        .table-card .status.rejected {
            color: #fda4af;
            border-color: rgba(251, 113, 133, .3);
            background: rgba(225, 29, 72, .12);
        }

        /* Close / Reopen buttons */
        .table-card .btn.small {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            min-width: 84px;
            padding: 10px 15px;
            border: 1px solid rgba(129, 140, 248, .28);
            border-radius: 10px;
            background: linear-gradient(110deg, #0891b2, #4f46e5, #9333ea);
            color: #fff;
            font-size: 12px;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 5px 16px rgba(79, 70, 229, .2);
            transition: transform .2s ease, filter .2s ease, box-shadow .2s ease;
        }

        .table-card .btn.small:hover {
            transform: translateY(-2px);
            filter: brightness(1.15);
            box-shadow: 0 8px 22px rgba(34, 211, 238, .18);
        }

        .table-card form {
            margin: 0;
        }

        /* Floating code symbols */
        .ts-floating-code {
            position: fixed;
            z-index: 0;
            pointer-events: none;
            user-select: none;
            font-family: monospace;
            font-weight: 800;
            color: rgba(103, 232, 249, .2);
            text-shadow: 0 0 18px rgba(34, 211, 238, .2);
            animation: tsFloatCode 7s ease-in-out infinite;
        }

        .ts-code-left {
            top: 38%;
            left: 13px;
            font-size: 25px;
        }

        .ts-code-right {
            right: 17px;
            bottom: 20%;
            color: rgba(192, 132, 252, .23);
            font-size: 27px;
            animation-delay: -3s;
        }

        @keyframes tsFloatCode {
            0%, 100% { transform: translateY(0) rotate(-3deg); }
            50% { transform: translateY(-17px) rotate(4deg); }
        }

        /* Responsive */
        @media (max-width: 850px) {
            .dashboard {
                width: calc(100% - 26px);
                margin-top: 25px;
            }

            .table-card {
                overflow-x: auto;
            }

            .table-card table {
                min-width: 680px;
            }

            .page-heading {
                padding: 24px;
            }
        }

        @media (max-width: 600px) {
            .dashboard {
                width: calc(100% - 20px);
                margin: 18px auto 40px;
            }

            .page-heading {
                align-items: flex-start;
                flex-direction: column;
                gap: 20px;
                padding: 22px 18px;
                border-radius: 17px;
            }

            .page-heading h1 {
                font-size: 34px;
            }

            .page-heading .btn.primary {
                width: 100%;
            }

            .page-heading::after {
                right: 15px;
                top: 12px;
            }

            .table-card {
                border-radius: 15px;
            }

            .table-card th,
            .table-card td {
                padding: 14px;
            }

            .ts-code-left,
            .ts-code-right {
                display: none;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            body::before,
            body::after,
            .page-heading::before,
            .page-heading::after,
            .page-heading h1,
            .table-card::before,
            .ts-floating-code {
                animation: none !important;
            }

            .page-heading .btn.primary,
            .table-card tbody tr,
            .table-card td,
            .table-card .btn.small {
                transition: none !important;
            }
        }
    </style>
</head>

<body>

    <!-- Floating technology decorations -->
    <div class="ts-floating-code ts-code-left" aria-hidden="true">&lt;/&gt;</div>
    <div class="ts-floating-code ts-code-right" aria-hidden="true">{ }</div>

    <?php include 'company_nav.php'; ?>

    <main class="dashboard">

        <div class="page-heading">
            <div>
                <p class="eyebrow">◈ ROLE MANAGEMENT</p>
                <h1>My internships.</h1>
                <p>Control which opportunities are currently accepting applications.</p>
            </div>

            <a class="btn primary" href="add_internship.php">
                Add new
            </a>
        </div>

        <?php if ($flash): ?>
            <div class="alert success">
                <?= e($flash['message']) ?>
            </div>
        <?php endif; ?>

        <?php if ($message): ?>
            <div class="alert success">
                <?= e($message) ?>
            </div>
        <?php endif; ?>

        <div class="table-card">
            <table>
                <thead>
                    <tr>
                        <th>Role</th>
                        <th>Location</th>
                        <th>Applicants</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (!$rows): ?>
                        <tr>
                            <td colspan="5" class="empty">
                                No internships posted yet.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($rows as $r): ?>
                            <tr>
                                <td>
                                    <strong><?= e($r['title']) ?></strong>
                                    <br>
                                    <small>
                                        <?= e($r['duration'] ?: 'Duration not set') ?>
                                    </small>
                                </td>

                                <td><?= e($r['location']) ?></td>

                                <td><?= e($r['applicant_count']) ?></td>

                                <td>
                                    <span class="status <?= $r['status'] === 'Open' ? 'open' : 'rejected' ?>">
                                        <?= e($r['status']) ?>
                                    </span>
                                </td>

                                <td>
                                    <form method="POST">
                                        <input
                                            type="hidden"
                                            name="internship_id"
                                            value="<?= $r['id'] ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="toggle"
                                        >

                                        <button class="btn small" type="submit">
                                            <?= $r['status'] === 'Open' ? 'Close' : 'Reopen' ?>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </main>

</body>
</html>
