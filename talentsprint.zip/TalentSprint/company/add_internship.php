<?php

session_start();

require_once __DIR__ . '/../config/database.php';

require_role('company');

$data = db_load();

$company = db_company_by_user($data, (int) $_SESSION['user_id']);

$cid = (int) ($company['id'] ?? 0);

$error = '';

$title = $description = $location = $skills = $duration = $stipend = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $skills = trim($_POST['skills'] ?? '');
    $duration = trim($_POST['duration'] ?? '');
    $stipend = trim($_POST['stipend'] ?? '');

    if ($title === '' || $description === '' || $location === '') {

        $error = 'Please complete the title, description and location.';

    } else {

        $data['internships'][] = [
            'id' => db_next_id($data, 'internships'),
            'company_id' => $cid,
            'title' => $title,
            'description' => $description,
            'location' => $location,
            'skills' => $skills,
            'duration' => $duration,
            'stipend' => $stipend,
            'status' => 'Open',
            'created_at' => db_now()
        ];

        if (db_save($data)) {

            flash('success', 'Internship published successfully.');

            header('Location: internships.php');

            exit;

        } else {

            $error = 'Unable to save the internship.';

        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Post Internship · TalentSprint</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>
        /* =========================================
           TALENTSPRINT GALAXY THEME
        ========================================= */

        body {
            background:
                radial-gradient(ellipse at 10% 15%, rgba(91, 61, 190, .23), transparent 35%),
                radial-gradient(ellipse at 90% 80%, rgba(0, 213, 255, .15), transparent 35%),
                linear-gradient(135deg, #050816, #0b1026 50%, #10132e) !important;
            color: #f4f6ff;
            min-height: 100vh;
            overflow-x: hidden;
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: -1;
            opacity: .55;
            background-image:
                radial-gradient(2px 2px at 8% 20%, #ffffff 50%, transparent 100%),
                radial-gradient(2px 2px at 25% 75%, #6ee7ff 50%, transparent 100%),
                radial-gradient(1px 1px at 45% 35%, #ffffff 50%, transparent 100%),
                radial-gradient(2px 2px at 67% 15%, #c4b5fd 50%, transparent 100%),
                radial-gradient(1px 1px at 83% 64%, #ffffff 50%, transparent 100%),
                radial-gradient(2px 2px at 94% 33%, #f0abfc 50%, transparent 100%);
            background-size: 240px 240px;
            animation: tsStars 18s linear infinite;
        }

        @keyframes tsStars {
            from { transform: translateY(0); }
            to   { transform: translateY(-120px); }
        }

        .dashboard.narrow {
            position: relative;
            width: min(920px, calc(100% - 36px));
            margin: 48px auto 80px;
            padding: 30px;
            border: 1px solid rgba(125, 211, 252, .13);
            border-radius: 28px;
            background: rgba(8, 13, 35, .64);
            box-shadow: 0 25px 80px rgba(0, 0, 0, .3);
            backdrop-filter: blur(14px);
            isolation: isolate;
        }

        .page-heading {
            margin-bottom: 28px;
            animation: tsFadeIn .7s ease both;
        }

        .page-heading .eyebrow {
            display: inline-block;
            padding: 8px 13px;
            border: 1px solid rgba(103, 232, 249, .3);
            border-radius: 999px;
            color: #67e8f9;
            background: rgba(34, 211, 238, .08);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 3px;
        }

        .page-heading h1 {
            margin: 12px 0;
            color: #fff;
            font-size: clamp(32px, 5vw, 46px);
            font-weight: 850;
            letter-spacing: -1.5px;
            line-height: 1.15;
            background: linear-gradient(100deg, #ffffff, #67e8f9, #c4b5fd, #f0abfc);
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
            background-size: 250% auto;
            animation: tsGradient 7s linear infinite;
        }

        .page-heading > div > p:last-child {
            color: #aab7d7;
            line-height: 1.7;
        }

        @keyframes tsGradient {
            0% { background-position: 0% center; }
            100% { background-position: 250% center; }
        }

        .form-card {
            position: relative;
            padding: clamp(20px, 4vw, 36px);
            border: 1px solid rgba(148, 163, 255, .22);
            border-radius: 24px;
            background:
                linear-gradient(145deg, rgba(21, 29, 66, .96), rgba(10, 18, 43, .97));
            box-shadow:
                0 20px 60px rgba(0, 0, 0, .22),
                inset 0 1px 0 rgba(255, 255, 255, .04);
            animation: tsFadeIn .9s ease both;
        }

        .form-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 12%;
            right: 12%;
            height: 2px;
            border-radius: 50%;
            background: linear-gradient(90deg, transparent, #22d3ee, #a78bfa, #f0abfc, transparent);
            box-shadow: 0 0 18px rgba(34, 211, 238, .4);
        }

        .form-card label {
            display: block;
            margin: 18px 0 9px;
            color: #dce8ff;
            font-size: 13px;
            font-weight: 750;
            letter-spacing: .3px;
        }

        .form-card input,
        .form-card textarea {
            box-sizing: border-box;
            width: 100%;
            padding: 14px 16px;
            border: 1px solid rgba(148, 163, 255, .24);
            border-radius: 13px;
            outline: none;
            background: rgba(5, 10, 29, .78);
            color: #f8fbff;
            font: inherit;
            font-size: 14px;
            transition:
                border-color .25s ease,
                box-shadow .25s ease,
                background .25s ease,
                transform .25s ease;
        }

        .form-card textarea {
            min-height: 155px;
            resize: vertical;
            line-height: 1.7;
        }

        .form-card input::placeholder,
        .form-card textarea::placeholder {
            color: #7482a8;
        }

        .form-card input:focus,
        .form-card textarea:focus {
            border-color: #67e8f9;
            background: rgba(9, 17, 43, .98);
            box-shadow:
                0 0 0 3px rgba(34, 211, 238, .1),
                0 0 22px rgba(34, 211, 238, .09);
            transform: translateY(-1px);
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 8px 22px;
            margin-top: 8px;
        }

        .form-card .btn.primary {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 28px;
            padding: 15px 24px;
            border: 0;
            border-radius: 13px;
            background: linear-gradient(110deg, #06b6d4, #6366f1 55%, #a855f7);
            color: #fff;
            font-size: 14px;
            font-weight: 800;
            letter-spacing: .2px;
            box-shadow: 0 9px 28px rgba(99, 102, 241, .28);
            cursor: pointer;
            transition: transform .25s ease, box-shadow .25s ease, filter .25s ease;
        }

        .form-card .btn.primary::after {
            content: "✦";
            font-size: 17px;
        }

        .form-card .btn.primary:hover {
            transform: translateY(-3px);
            filter: brightness(1.12);
            box-shadow: 0 14px 36px rgba(34, 211, 238, .24);
        }

        .alert.error {
            margin: 0 0 22px;
            padding: 14px 17px;
            border: 1px solid rgba(251, 113, 133, .4);
            border-radius: 13px;
            background: rgba(159, 18, 57, .18);
            color: #fecdd3;
        }

        @keyframes tsFadeIn {
            from { opacity: 0; transform: translateY(18px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        /* =========================================
           TWO SEATED HUMAN CHARACTERS WITH LAPTOPS
        ========================================= */

        .ts-border-people {
            position: fixed;
            inset: 0;
            z-index: 5;
            overflow: hidden;
            pointer-events: none;
        }

        .ts-person {
            position: absolute;
            width: 64px;
            height: 94px;
            filter: drop-shadow(0 0 12px rgba(103, 232, 249, .18));
            animation: tsSitFloat 4s ease-in-out infinite;
        }

        .ts-person svg {
            display: block;
            width: 100%;
            height: 100%;
            overflow: visible;
        }

        .ts-person-left {
            left: 10px;
            bottom: 8%;
            animation-delay: -1.4s;
        }

        .ts-person-right {
            right: 10px;
            top: 28%;
            animation-delay: -.5s;
        }

        @keyframes tsSitFloat {
            0%, 100% { transform: translateY(0) rotate(-2deg); }
            50%      { transform: translateY(-9px) rotate(2deg); }
        }

        /* Animated laptop screens */
        .ts-laptop {
            transform-origin: center;
            animation: tsLaptopGlow 3s ease-in-out infinite;
        }

        @keyframes tsLaptopGlow {
            0%, 100% {
                filter: drop-shadow(0 0 2px rgba(103, 232, 249, .25));
            }
            50% {
                filter: drop-shadow(0 0 8px rgba(103, 232, 249, .85));
            }
        }

        /* Glowing orbs */
        .ts-orb {
            position: absolute;
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: #67e8f9;
            box-shadow: 0 0 13px #67e8f9;
            animation: tsOrb 5s linear infinite;
        }

        .ts-orb-left {
            left: 37px;
            bottom: calc(8% + 95px);
        }

        .ts-orb-right {
            right: 36px;
            top: calc(28% - 5px);
            background: #c4b5fd;
            box-shadow: 0 0 13px #c4b5fd;
            animation-delay: -2s;
        }

        @keyframes tsOrb {
            0%   { transform: translate(0, 0) scale(.8); opacity: .5; }
            50%  { transform: translate(15px, -20px) scale(1.3); opacity: 1; }
            100% { transform: translate(0, 0) scale(.8); opacity: .5; }
        }

        /* Shooting stars */
        .ts-shooting-star {
            position: fixed;
            top: 16%;
            left: -120px;
            z-index: -1;
            width: 100px;
            height: 2px;
            pointer-events: none;
            background: linear-gradient(90deg, transparent, #67e8f9, transparent);
            box-shadow: 0 0 10px #67e8f9;
            transform: rotate(-25deg);
            animation: tsShoot 9s linear infinite;
        }

        .ts-shooting-star.two {
            top: 64%;
            animation-delay: -4.5s;
            animation-duration: 12s;
            background: linear-gradient(90deg, transparent, #c4b5fd, transparent);
            box-shadow: 0 0 10px #c4b5fd;
        }

        @keyframes tsShoot {
            0%   { left: -120px; opacity: 0; }
            5%   { opacity: .9; }
            18%  { opacity: 0; }
            100% { left: 110%; opacity: 0; }
        }

        @media (max-width: 700px) {
            .dashboard.narrow {
                width: calc(100% - 24px);
                margin: 24px auto 50px;
                padding: 18px 14px;
            }

            .form-grid {
                grid-template-columns: 1fr;
                gap: 0;
            }

            .form-card {
                padding: 20px 16px;
            }

            .ts-person-left {
                left: -16px;
                bottom: 5%;
                transform: scale(.72);
            }

            .ts-person-right {
                right: -16px;
                top: 35%;
                transform: scale(.72);
            }

            .form-card .btn.primary {
                width: 100%;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            body::before,
            .page-heading h1,
            .page-heading,
            .form-card,
            .ts-person,
            .ts-orb,
            .ts-shooting-star,
            .ts-laptop {
                animation: none !important;
            }

            .form-card input,
            .form-card textarea,
            .form-card .btn.primary {
                transition: none !important;
            }
        }
    </style>
</head>

<body>

<div class="ts-border-people" aria-hidden="true">

    <!-- Left seated character with laptop -->
    <div class="ts-person ts-person-left">
        <svg viewBox="0 0 70 100" xmlns="http://www.w3.org/2000/svg">

            <!-- Seat -->
            <path d="M15 67 H48 L53 84 H17 Z"
                  fill="#27365f" stroke="#67e8f9" stroke-width="1.5"/>

            <path d="M20 84 V94 M49 84 V94"
                  stroke="#67e8f9" stroke-width="3" stroke-linecap="round"/>

            <!-- Head -->
            <circle cx="32" cy="23" r="11"
                    fill="#f4bf98" stroke="#ffd9bd" stroke-width="1"/>

            <!-- Hair -->
            <path d="M21 24 Q18 10 30 9 Q43 8 44 21 L40 17 L25 18 Z"
                  fill="#25213e"/>

            <!-- Body -->
            <path d="M23 36 Q31 31 40 37 L46 63 L19 63 Z"
                  fill="#8b5cf6" stroke="#c4b5fd" stroke-width="1.5"/>

            <!-- Arms holding laptop -->
            <path d="M24 40 L21 49 L29 54"
                  fill="none" stroke="#f4bf98" stroke-width="5"
                  stroke-linecap="round" stroke-linejoin="round"/>

            <path d="M39 40 L45 49 L40 54"
                  fill="none" stroke="#f4bf98" stroke-width="5"
                  stroke-linecap="round" stroke-linejoin="round"/>

            <!-- Laptop -->
            <g class="ts-laptop">
                <rect x="25" y="43" width="23" height="16" rx="2"
                      fill="#101a38" stroke="#67e8f9" stroke-width="1.8"/>

                <rect x="28" y="46" width="17" height="10" rx="1"
                      fill="#164e63"/>

                <path d="M31 49 H40 M31 52 H37"
                      stroke="#67e8f9" stroke-width="1"
                      stroke-linecap="round"/>

                <path d="M22 60 H51 L47 63 H25 Z"
                      fill="#a78bfa" stroke="#c4b5fd" stroke-width="1"/>
            </g>

            <!-- Sitting legs -->
            <path d="M23 62 L35 72 L49 72"
                  fill="none" stroke="#22d3ee" stroke-width="7"
                  stroke-linecap="round" stroke-linejoin="round"/>

            <path d="M39 62 L35 77 L21 77"
                  fill="none" stroke="#22d3ee" stroke-width="7"
                  stroke-linecap="round" stroke-linejoin="round"/>

            <!-- Shoes -->
            <path d="M45 72 H54 M16 77 H24"
                  stroke="#f0abfc" stroke-width="5"
                  stroke-linecap="round"/>

            <!-- Eye -->
            <circle cx="36" cy="23" r="1.3" fill="#34243a"/>

        </svg>
    </div>

    <!-- Right seated character with laptop -->
    <div class="ts-person ts-person-right">
        <svg viewBox="0 0 70 100" xmlns="http://www.w3.org/2000/svg">

            <!-- Seat -->
            <path d="M15 67 H48 L53 84 H17 Z"
                  fill="#27365f" stroke="#c4b5fd" stroke-width="1.5"/>

            <path d="M20 84 V94 M49 84 V94"
                  stroke="#c4b5fd" stroke-width="3" stroke-linecap="round"/>

            <!-- Head -->
            <circle cx="34" cy="23" r="11"
                    fill="#d99b76" stroke="#ffd9bd" stroke-width="1"/>

            <!-- Hair -->
            <path d="M23 24 Q20 10 34 9 Q47 10 45 25 L41 17 L25 19 Z"
                  fill="#18233f"/>

            <!-- Body -->
            <path d="M25 36 Q33 31 42 37 L47 63 L21 63 Z"
                  fill="#06b6d4" stroke="#67e8f9" stroke-width="1.5"/>

            <!-- Arms holding laptop -->
            <path d="M26 41 L22 49 L30 54"
                  fill="none" stroke="#d99b76" stroke-width="5"
                  stroke-linecap="round" stroke-linejoin="round"/>

            <path d="M41 41 L47 49 L40 54"
                  fill="none" stroke="#d99b76" stroke-width="5"
                  stroke-linecap="round" stroke-linejoin="round"/>

            <!-- Laptop -->
            <g class="ts-laptop">
                <rect x="24" y="43" width="23" height="16" rx="2"
                      fill="#101a38" stroke="#c4b5fd" stroke-width="1.8"/>

                <rect x="27" y="46" width="17" height="10" rx="1"
                      fill="#312e81"/>

                <path d="M30 49 H39 M30 52 H36"
                      stroke="#67e8f9" stroke-width="1"
                      stroke-linecap="round"/>

                <path d="M21 60 H50 L46 63 H24 Z"
                      fill="#06b6d4" stroke="#67e8f9" stroke-width="1"/>
            </g>

            <!-- Sitting legs -->
            <path d="M25 62 L37 72 L50 72"
                  fill="none" stroke="#a78bfa" stroke-width="7"
                  stroke-linecap="round" stroke-linejoin="round"/>

            <path d="M40 62 L36 77 L22 77"
                  fill="none" stroke="#a78bfa" stroke-width="7"
                  stroke-linecap="round" stroke-linejoin="round"/>

            <!-- Shoes -->
            <path d="M46 72 H55 M17 77 H25"
                  stroke="#f0abfc" stroke-width="5"
                  stroke-linecap="round"/>

            <!-- Eye -->
            <circle cx="38" cy="23" r="1.3" fill="#34243a"/>

        </svg>
    </div>

    <!-- Floating glowing orbs -->
    <span class="ts-orb ts-orb-left"></span>
    <span class="ts-orb ts-orb-right"></span>

</div>

<!-- Shooting stars -->
<div class="ts-shooting-star"></div>
<div class="ts-shooting-star two"></div>

<?php include 'company_nav.php'; ?>

<main class="dashboard narrow">

    <div class="page-heading">
        <div>
            <p class="eyebrow">✦ NEW OPPORTUNITY</p>
            <h1>Post an internship.</h1>
            <p>Give students the information they need to apply confidently.</p>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="alert error"><?= e($error) ?></div>
    <?php endif; ?>

    <div class="form-card">

        <form method="POST">

            <label>Internship title *</label>
            <input
                name="title"
                value="<?= e($title) ?>"
                placeholder="e.g. Full Stack Developer Intern"
                required
            >

            <label>Description *</label>
            <textarea
                name="description"
                rows="7"
                placeholder="Responsibilities, requirements and what the intern will learn..."
                required
            ><?= e($description) ?></textarea>

            <div class="form-grid">

                <div>
                    <label>Location *</label>
                    <input
                        name="location"
                        value="<?= e($location) ?>"
                        placeholder="Chennai / Remote"
                        required
                    >
                </div>

                <div>
                    <label>Skills</label>
                    <input
                        name="skills"
                        value="<?= e($skills) ?>"
                        placeholder="PHP, MySQL, JavaScript"
                    >
                </div>

                <div>
                    <label>Duration</label>
                    <input
                        name="duration"
                        value="<?= e($duration) ?>"
                        placeholder="3 months"
                    >
                </div>

                <div>
                    <label>Stipend</label>
                    <input
                        name="stipend"
                        value="<?= e($stipend) ?>"
                        placeholder="₹10,000 / month"
                    >
                </div>

            </div>

            <button class="btn primary" type="submit">
                Publish internship
            </button>

        </form>

    </div>

</main>

</body>
</html>