<?php
session_start();

require_once __DIR__ . '/../config/database.php';

require_role('company');

$data = db_load();
$company = db_company_by_user($data, (int) $_SESSION['user_id']);
$cid = (int) ($company['id'] ?? 0);

$allowed = ['Under Review', 'Shortlisted', 'Interview', 'Selected', 'Rejected'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aid = (int) ($_POST['application_id'] ?? 0);
    $new = $_POST['status'] ?? '';

    if (in_array($new, $allowed, true)) {
        foreach ($data['applications'] as &$a) {
            $i = db_internship($data, (int) $a['internship_id']);

            if (
                (int) $a['id'] === $aid &&
                $i &&
                (int) $i['company_id'] === $cid
            ) {
                $a['status'] = $new;
            }
        }

        unset($a);

        if (db_save($data)) {
            $message = 'Application status updated.';
        }
    }
}

$rows = [];

foreach ($data['applications'] as $a) {
    $i = db_internship($data, (int) $a['internship_id']);

    if (!$i || (int) $i['company_id'] !== $cid) {
        continue;
    }

    $s = null;

    foreach ($data['students'] as $st) {
        if ((int) $st['id'] === (int) $a['student_id']) {
            $s = $st;
        }
    }

    $u = $s ? db_user($data, (int) $s['user_id']) : null;

    if (!$u) {
        continue;
    }

    $a['student_name'] = $u['name'];
    $a['email'] = $u['email'];
    $a['skills'] = $s['skills'] ?? '';
    $a['college'] = $s['college'] ?? '';
    $a['title'] = $i['title'];

    $rows[] = $a;
}

usort($rows, fn($a, $b) => strcmp($b['applied_at'], $a['applied_at']));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Applicants · TalentSprint</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>
        /* ==========================================
           TALENTSPRINT — FUTURISTIC TECH DASHBOARD
           All styles are local to this page.
        ========================================== */

        body {
            min-height: 100vh;
            overflow-x: hidden;
            color: #edf4ff !important;
            background:
                radial-gradient(ellipse at 12% 10%, rgba(0, 212, 255, .13), transparent 34%),
                radial-gradient(ellipse at 88% 75%, rgba(139, 92, 246, .15), transparent 35%),
                linear-gradient(135deg, #050816 0%, #0a1025 52%, #11102b 100%) !important;
        }

        /* Moving digital grid */
        body::before {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -2;
            pointer-events: none;
            background-image:
                linear-gradient(rgba(56, 189, 248, .055) 1px, transparent 1px),
                linear-gradient(90deg, rgba(56, 189, 248, .055) 1px, transparent 1px);
            background-size: 42px 42px;
            mask-image: linear-gradient(to bottom, black, transparent 90%);
            animation: tsGridMove 22s linear infinite;
        }

        /* Digital light particles */
        body::after {
            content: "";
            position: fixed;
            inset: 0;
            z-index: -1;
            pointer-events: none;
            opacity: .65;
            background-image:
                radial-gradient(2px 2px at 12% 22%, #67e8f9 50%, transparent 100%),
                radial-gradient(2px 2px at 24% 68%, #a78bfa 50%, transparent 100%),
                radial-gradient(2px 2px at 45% 30%, #ffffff 50%, transparent 100%),
                radial-gradient(2px 2px at 69% 72%, #22d3ee 50%, transparent 100%),
                radial-gradient(2px 2px at 82% 18%, #c084fc 50%, transparent 100%),
                radial-gradient(2px 2px at 93% 49%, #67e8f9 50%, transparent 100%);
            background-size: 280px 280px;
            animation: tsParticleMove 30s linear infinite;
        }

        @keyframes tsGridMove {
            from { background-position: 0 0; }
            to   { background-position: 42px 42px; }
        }

        @keyframes tsParticleMove {
            from { transform: translateY(0); }
            to   { transform: translateY(-100px); }
        }

        /* Main dashboard */
        .dashboard {
            position: relative;
            z-index: 1;
            width: min(1440px, calc(100% - 48px));
            margin: 45px auto 70px;
            animation: tsFadeUp .8s ease both;
        }

        @keyframes tsFadeUp {
            from {
                opacity: 0;
                transform: translateY(18px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Heading */
        .page-heading {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 24px;
            margin-bottom: 32px;
            padding: 30px;
            overflow: hidden;
            border: 1px solid rgba(103, 232, 249, .2);
            border-radius: 24px;
            background: linear-gradient(
                115deg,
                rgba(8, 24, 51, .94),
                rgba(24, 19, 58, .9)
            );
            box-shadow: 0 18px 60px rgba(0, 0, 0, .2);
        }

        .page-heading::before {
            content: "";
            position: absolute;
            top: 0;
            left: -40%;
            width: 35%;
            height: 2px;
            background: linear-gradient(90deg, transparent, #22d3ee, #c084fc, transparent);
            box-shadow: 0 0 18px #22d3ee;
            animation: tsScanLine 6s ease-in-out infinite;
        }

        @keyframes tsScanLine {
            0%   { left: -40%; }
            100% { left: 110%; }
        }

        .page-heading .eyebrow {
            margin: 0 0 12px;
            color: #67e8f9;
            font-size: 11px;
            font-weight: 850;
            letter-spacing: 3px;
        }

        .page-heading h1 {
            margin: 0 0 12px;
            color: #fff;
            font-size: clamp(34px, 5vw, 48px);
            font-weight: 850;
            letter-spacing: -1.5px;
            background: linear-gradient(100deg, #ffffff, #67e8f9, #a78bfa, #f0abfc);
            background-size: 250% auto;
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: tsTextGlow 8s linear infinite;
        }

        @keyframes tsTextGlow {
            to { background-position: 250% center; }
        }

        .page-heading > div > p:last-child {
            margin: 0;
            color: #a9badb;
            font-size: 14px;
            line-height: 1.7;
        }

        /* Animated tech ring */
        .ts-tech-ring {
            position: absolute;
            right: 48px;
            top: 50%;
            width: 90px;
            height: 90px;
            border: 1px solid rgba(103, 232, 249, .5);
            border-radius: 50%;
            transform: translateY(-50%);
            box-shadow:
                0 0 22px rgba(34, 211, 238, .1),
                inset 0 0 20px rgba(34, 211, 238, .08);
            animation: tsRingPulse 3s ease-in-out infinite;
        }

        .ts-tech-ring::before,
        .ts-tech-ring::after {
            content: "";
            position: absolute;
            inset: 10px;
            border: 1px dashed rgba(167, 139, 250, .8);
            border-radius: 50%;
            animation: tsRingRotate 12s linear infinite;
        }

        .ts-tech-ring::after {
            inset: 23px;
            border-style: solid;
            border-color: rgba(34, 211, 238, .75);
            animation-direction: reverse;
            animation-duration: 7s;
        }

        .ts-tech-ring span {
            position: absolute;
            top: -4px;
            left: 40px;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #67e8f9;
            box-shadow: 0 0 12px #67e8f9;
        }

        @keyframes tsRingRotate {
            to { transform: rotate(360deg); }
        }

        @keyframes tsRingPulse {
            0%, 100% { opacity: .75; }
            50% { opacity: 1; box-shadow: 0 0 32px rgba(34, 211, 238, .2); }
        }

        /* Success notification */
        .alert.success {
            margin: 0 0 22px;
            padding: 16px 20px;
            color: #a7f3d0;
            background: rgba(6, 95, 70, .22);
            border: 1px solid rgba(52, 211, 153, .4);
            border-radius: 14px;
            box-shadow: 0 0 22px rgba(52, 211, 153, .06);
            animation: tsFadeUp .4s ease both;
        }

        /* Applicants table card */
        .table-card {
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(103, 232, 249, .19);
            border-radius: 22px;
            background: rgba(8, 15, 36, .91);
            box-shadow:
                0 24px 70px rgba(0, 0, 0, .24),
                inset 0 1px 0 rgba(255, 255, 255, .025);
            backdrop-filter: blur(14px);
        }

        .table-card::before {
            content: "";
            position: absolute;
            z-index: 1;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, #22d3ee, #6366f1, #d946ef, #22d3ee);
            background-size: 200% 100%;
            animation: tsBorderFlow 5s linear infinite;
        }

        @keyframes tsBorderFlow {
            to { background-position: 200% 0; }
        }

        .table-card table {
            width: 100%;
            border-collapse: collapse;
            color: #e5edff;
        }

        .table-card thead {
            background: linear-gradient(
                90deg,
                rgba(8, 145, 178, .18),
                rgba(99, 102, 241, .16),
                rgba(147, 51, 234, .15)
            );
        }

        .table-card th {
            padding: 19px 18px;
            color: #8eeaff;
            font-size: 11px;
            font-weight: 850;
            letter-spacing: 1.2px;
            text-align: left;
            text-transform: uppercase;
            white-space: nowrap;
            border-bottom: 1px solid rgba(103, 232, 249, .17);
        }

        .table-card td {
            padding: 19px 18px;
            color: #cbd7f1;
            font-size: 13px;
            line-height: 1.7;
            vertical-align: middle;
            border-bottom: 1px solid rgba(148, 163, 255, .1);
            transition: background .25s ease;
        }

        .table-card tbody tr {
            transition: background .25s ease, box-shadow .25s ease;
        }

        .table-card tbody tr:hover {
            background: rgba(34, 211, 238, .055);
            box-shadow: inset 3px 0 0 #22d3ee;
        }

        .table-card tbody tr:last-child td {
            border-bottom: none;
        }

        .table-card td strong {
            color: #f3f7ff;
            font-size: 14px;
            font-weight: 750;
        }

        .table-card td small {
            color: #8c9fc4;
            overflow-wrap: anywhere;
        }

        .table-card .empty {
            padding: 42px 20px;
            color: #9aabd0;
            text-align: center;
        }

        /* Status labels */
        .table-card .status {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 6px 10px;
            border: 1px solid rgba(148, 163, 184, .25);
            border-radius: 999px;
            background: rgba(51, 65, 85, .28);
            color: #dbeafe;
            font-size: 11px;
            font-weight: 800;
            white-space: nowrap;
        }

        .table-card .status::before {
            content: "";
            width: 6px;
            height: 6px;
            flex: 0 0 6px;
            border-radius: 50%;
            background: currentColor;
            box-shadow: 0 0 8px currentColor;
        }

        .table-card .status.s-under-review {
            color: #67e8f9;
            border-color: rgba(34, 211, 238, .3);
            background: rgba(8, 145, 178, .12);
        }

        .table-card .status.s-shortlisted {
            color: #c4b5fd;
            border-color: rgba(167, 139, 250, .3);
            background: rgba(124, 58, 237, .13);
        }

        .table-card .status.s-interview {
            color: #f0abfc;
            border-color: rgba(232, 121, 249, .3);
            background: rgba(192, 38, 211, .12);
        }

        .table-card .status.s-selected {
            color: #6ee7b7;
            border-color: rgba(52, 211, 153, .3);
            background: rgba(5, 150, 105, .13);
        }

        .table-card .status.s-rejected {
            color: #fda4af;
            border-color: rgba(251, 113, 133, .3);
            background: rgba(225, 29, 72, .12);
        }

        /* Update-status controls */
        .table-card .inline-form {
            display: flex;
            align-items: center;
            gap: 8px;
            min-width: 210px;
        }

        .table-card select {
            min-width: 120px;
            max-width: 170px;
            padding: 10px 9px;
            border: 1px solid rgba(129, 140, 248, .32);
            border-radius: 10px;
            outline: none;
            background: #101936;
            color: #e8f1ff;
            font-size: 12px;
            cursor: pointer;
            transition: border-color .2s ease, box-shadow .2s ease;
        }

        .table-card select:focus {
            border-color: #67e8f9;
            box-shadow: 0 0 0 3px rgba(34, 211, 238, .1);
        }

        .table-card select option {
            background: #101936;
            color: #f3f7ff;
        }

        .table-card .btn.small {
            padding: 10px 14px;
            border: 0;
            border-radius: 10px;
            background: linear-gradient(110deg, #0891b2, #4f46e5, #9333ea);
            color: white;
            font-size: 12px;
            font-weight: 800;
            cursor: pointer;
            white-space: nowrap;
            box-shadow: 0 5px 16px rgba(79, 70, 229, .22);
            transition: transform .2s ease, filter .2s ease, box-shadow .2s ease;
        }

        .table-card .btn.small:hover {
            transform: translateY(-2px);
            filter: brightness(1.15);
            box-shadow: 0 8px 22px rgba(34, 211, 238, .18);
        }

        /* Floating tech icons */
        .ts-floating-tech {
            position: fixed;
            z-index: 0;
            pointer-events: none;
            user-select: none;
            font-family: monospace;
            font-weight: 800;
            color: rgba(103, 232, 249, .18);
            text-shadow: 0 0 16px rgba(34, 211, 238, .16);
            animation: tsFloatTech 8s ease-in-out infinite;
        }

        .ts-tech-one {
            top: 28%;
            left: 18px;
            font-size: 27px;
        }

        .ts-tech-two {
            right: 20px;
            bottom: 19%;
            font-size: 24px;
            color: rgba(192, 132, 252, .23);
            animation-delay: -3s;
        }

        .ts-tech-three {
            right: 9%;
            top: 15%;
            font-size: 17px;
            animation-delay: -5s;
        }

        @keyframes tsFloatTech {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-17px) rotate(5deg); }
        }

        /* Responsive design */
        @media (max-width: 1000px) {
            .dashboard {
                width: calc(100% - 28px);
                margin-top: 25px;
            }

            .table-card {
                overflow-x: auto;
            }

            .table-card table {
                min-width: 850px;
            }

            .ts-tech-ring {
                right: 28px;
                width: 70px;
                height: 70px;
            }
        }

        @media (max-width: 600px) {
            .dashboard {
                width: calc(100% - 20px);
                margin: 18px auto 40px;
            }

            .page-heading {
                padding: 23px 19px;
                border-radius: 18px;
            }

            .page-heading h1 {
                font-size: 34px;
            }

            .page-heading > div > p:last-child {
                max-width: 85%;
                font-size: 13px;
            }

            .ts-tech-ring {
                right: 14px;
                width: 48px;
                height: 48px;
                opacity: .6;
            }

            .ts-tech-ring::before {
                inset: 6px;
            }

            .ts-tech-ring::after {
                inset: 15px;
            }

            .table-card {
                border-radius: 15px;
            }

            .table-card th,
            .table-card td {
                padding: 14px;
            }

            .ts-tech-one,
            .ts-tech-two {
                display: none;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            body::before,
            body::after,
            .page-heading::before,
            .page-heading h1,
            .ts-tech-ring,
            .ts-tech-ring::before,
            .ts-tech-ring::after,
            .ts-tech-ring span,
            .table-card::before,
            .ts-floating-tech {
                animation: none !important;
            }

            .table-card tbody tr,
            .table-card td,
            .table-card .btn.small {
                transition: none !important;
            }
        }
    </style>
</head>

<body>

    <!-- Floating decorative technology symbols -->
    <div class="ts-floating-tech ts-tech-one" aria-hidden="true">&lt;/&gt;</div>
    <div class="ts-floating-tech ts-tech-two" aria-hidden="true">{ }</div>
    <div class="ts-floating-tech ts-tech-three" aria-hidden="true">01 · 10</div>

    <?php include 'company_nav.php'; ?>

    <main class="dashboard">

        <div class="page-heading">
            <div>
                <p class="eyebrow">◈ CANDIDATE PIPELINE</p>
                <h1>Applicants.</h1>
                <p>Review candidates and keep their application status current.</p>
            </div>

            <div class="ts-tech-ring" aria-hidden="true">
                <span></span>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert success"><?= e($message) ?></div>
        <?php endif; ?>

        <div class="table-card">
            <table>
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Internship</th>
                        <th>Skills</th>
                        <th>Applied</th>
                        <th>Status</th>
                        <th>Update</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (!$rows): ?>
                        <tr>
                            <td colspan="6" class="empty">
                                No applicants yet.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($rows as $r): ?>
                            <tr>
                                <td>
                                    <strong><?= e($r['student_name']) ?></strong>
                                    <br>
                                    <small><?= e($r['email']) ?></small>
                                </td>

                                <td><?= e($r['title']) ?></td>

                                <td><?= e($r['skills'] ?: 'Not added') ?></td>

                                <td>
                                    <?= e(date('d M Y', strtotime($r['applied_at']))) ?>
                                </td>

                                <td>
                                    <span class="status <?= e(status_class($r['status'])) ?>">
                                        <?= e($r['status']) ?>
                                    </span>
                                </td>

                                <td>
                                    <form method="POST" class="inline-form">
                                        <input
                                            type="hidden"
                                            name="application_id"
                                            value="<?= $r['id'] ?>"
                                        >

                                        <select name="status">
                                            <?php foreach ($allowed as $s): ?>
                                                <option <?= $r['status'] === $s ? 'selected' : '' ?>>
                                                    <?= e($s) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>

                                        <button class="btn small" type="submit">
                                            Save
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </main>

</body>
</html>