<?php
session_start();

require_once __DIR__ . '/../config/database.php';

require_role('student');

$data = db_load();

$student = db_student_by_user(
    $data,
    (int) $_SESSION['user_id']
);

$sid = (int) ($student['id'] ?? 0);

$rows = [];

foreach ($data['applications'] as $a) {
    if ((int) $a['student_id'] !== $sid) {
        continue;
    }

    $i = db_internship($data, (int) $a['internship_id']);

    if (!$i) {
        continue;
    }

    $c = db_company($data, (int) $i['company_id']);

    $a['title'] = $i['title'];
    $a['company_name'] = $c['company_name'] ?? 'Unknown';

    $rows[] = $a;
}

usort(
    $rows,
    fn($a, $b) => strcmp($b['applied_at'], $a['applied_at'])
);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Applications · TalentSprint</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>
        /* Styles apply only to this applications page. */

        body:has(.ts-applications-page) {
            --app-bg: #07091b;
            --app-panel: rgba(18, 23, 59, .9);
            --app-cyan: #00e5ff;
            --app-teal: #00f5c4;
            --app-blue: #477bff;
            --app-purple: #a855f7;
            --app-pink: #ff45d4;
            --app-orange: #ffae57;
            --app-text: #f8faff;
            --app-muted: #b4bfdc;

            min-height: 100vh;
            color: var(--app-text);

            background:
                radial-gradient(
                    ellipse at 10% 15%,
                    rgba(71, 123, 255, .18),
                    transparent 35%
                ),
                radial-gradient(
                    ellipse at 90% 20%,
                    rgba(168, 85, 247, .16),
                    transparent 35%
                ),
                radial-gradient(
                    ellipse at 55% 100%,
                    rgba(0, 245, 196, .08),
                    transparent 40%
                ),
                var(--app-bg);

            overflow-x: hidden;
        }

        .ts-applications-page {
            position: relative;
            isolation: isolate;
            max-width: 1250px;
            margin: 0 auto;
            padding: 45px 28px 70px;
        }

        /* Background stars */

        .ts-app-space {
            position: fixed;
            inset: 0;
            overflow: hidden;
            z-index: -1;
            pointer-events: none;
        }

        .ts-app-space .star {
            position: absolute;
            width: 3px;
            height: 3px;
            border-radius: 50%;
            background: white;
            box-shadow: 0 0 10px var(--app-cyan);
            animation: app-twinkle 3s ease-in-out infinite alternate;
        }

        .ts-app-space .star:nth-child(1) {
            top: 18%;
            left: 12%;
        }

        .ts-app-space .star:nth-child(2) {
            top: 32%;
            left: 85%;
            animation-delay: .8s;
        }

        .ts-app-space .star:nth-child(3) {
            top: 75%;
            left: 22%;
            animation-delay: 1.4s;
        }

        .ts-app-space .star:nth-child(4) {
            top: 85%;
            left: 72%;
            animation-delay: 2s;
        }

        .ts-app-space .shooting-star {
            position: absolute;
            top: 20%;
            left: 110%;
            width: 120px;
            height: 2px;
            opacity: 0;
            transform: rotate(-35deg);
            background: linear-gradient(
                90deg,
                transparent,
                var(--app-cyan),
                white
            );
            filter: drop-shadow(0 0 5px var(--app-cyan));
            animation: app-shoot 9s linear infinite;
        }

        .ts-app-space .shooting-star:nth-child(6) {
            top: 58%;
            animation-delay: 4s;
            animation-duration: 11s;
        }

        @keyframes app-twinkle {
            from {
                opacity: .25;
                transform: scale(.7);
            }

            to {
                opacity: 1;
                transform: scale(1.5);
            }
        }

        @keyframes app-shoot {
            0% {
                left: 110%;
                opacity: 0;
            }

            5% {
                opacity: 1;
            }

            20% {
                left: -25%;
                opacity: 0;
            }

            100% {
                left: -25%;
                opacity: 0;
            }
        }

        /* Page heading */

        .ts-applications-page .page-heading {
            position: relative;
            padding: 30px;
            margin-bottom: 28px;
            border: 1px solid rgba(133, 156, 255, .23);
            border-radius: 24px;

            background:
                linear-gradient(
                    120deg,
                    rgba(71, 123, 255, .14),
                    rgba(168, 85, 247, .1),
                    rgba(0, 245, 196, .05)
                ),
                var(--app-panel);

            box-shadow: 0 20px 55px rgba(0, 0, 0, .2);
            overflow: hidden;
            animation: app-enter .65s ease both;
        }

        .ts-applications-page .page-heading::after {
            content: "";
            position: absolute;
            width: 220px;
            height: 220px;
            top: -155px;
            right: 10%;
            border-radius: 50%;
            background: rgba(0, 229, 255, .1);
            filter: blur(28px);
            pointer-events: none;
        }

        .ts-applications-page .eyebrow {
            margin: 0 0 12px;
            color: var(--app-teal);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 3px;
        }

        .ts-applications-page .page-heading h1 {
            margin: 0 0 12px;
            font-size: clamp(30px, 4vw, 44px);
            font-weight: 850;
            line-height: 1.15;

            background: linear-gradient(
                90deg,
                #ffffff,
                var(--app-cyan),
                var(--app-purple),
                var(--app-pink)
            );

            background-size: 220% auto;
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;

            animation: app-gradient 7s linear infinite;
        }

        .ts-applications-page .page-heading p:not(.eyebrow) {
            margin: 0;
            color: var(--app-muted);
            line-height: 1.8;
        }

        @keyframes app-gradient {
            to {
                background-position: 220% center;
            }
        }

        @keyframes app-enter {
            from {
                opacity: 0;
                transform: translateY(15px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Application table container */

        .ts-applications-page .table-card {
            padding: 8px;
            border: 1px solid rgba(133, 156, 255, .2);
            border-radius: 22px;
            background: var(--app-panel);
            box-shadow: 0 20px 55px rgba(0, 0, 0, .22);
            overflow-x: auto;
            animation: app-enter .8s ease both;
            animation-delay: .12s;
        }

        .ts-applications-page table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            text-align: left;
        }

        .ts-applications-page thead {
            background: rgba(71, 123, 255, .1);
        }

        .ts-applications-page th {
            padding: 19px 20px;
            color: var(--app-cyan);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1.4px;
            text-transform: uppercase;
            white-space: nowrap;
            border-bottom: 1px solid rgba(133, 156, 255, .17);
        }

        .ts-applications-page th:first-child {
            border-radius: 13px 0 0 0;
        }

        .ts-applications-page th:last-child {
            border-radius: 0 13px 0 0;
        }

        .ts-applications-page td {
            padding: 20px;
            color: var(--app-muted);
            font-size: 14px;
            border-bottom: 1px solid rgba(133, 156, 255, .1);
            transition: background .25s ease;
        }

        .ts-applications-page tbody tr {
            animation: app-row-enter .5s ease both;
        }

        .ts-applications-page tbody tr:nth-child(1) {
            animation-delay: .08s;
        }

        .ts-applications-page tbody tr:nth-child(2) {
            animation-delay: .16s;
        }

        .ts-applications-page tbody tr:nth-child(3) {
            animation-delay: .24s;
        }

        .ts-applications-page tbody tr:nth-child(4) {
            animation-delay: .32s;
        }

        @keyframes app-row-enter {
            from {
                opacity: 0;
                transform: translateY(8px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .ts-applications-page tbody tr:hover td {
            background: rgba(71, 123, 255, .08);
        }

        .ts-applications-page tbody tr:last-child td {
            border-bottom: none;
        }

        .ts-applications-page td strong {
            color: var(--app-text);
            font-weight: 700;
        }

        /* Status badges */

        .ts-applications-page .status {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 7px 12px;
            border: 1px solid rgba(255, 255, 255, .13);
            border-radius: 30px;
            font-size: 12px;
            font-weight: 750;
            white-space: nowrap;
            background: rgba(255, 255, 255, .05);
        }

        .ts-applications-page .status::before {
            content: "";
            width: 6px;
            height: 6px;
            flex: 0 0 6px;
            border-radius: 50%;
            background: currentColor;
            box-shadow: 0 0 8px currentColor;
        }

        .ts-applications-page .status.s-applied {
            color: var(--app-cyan);
            background: rgba(0, 229, 255, .09);
            border-color: rgba(0, 229, 255, .25);
        }

        .ts-applications-page .status.s-under-review {
            color: #b8a0ff;
            background: rgba(168, 85, 247, .12);
            border-color: rgba(168, 85, 247, .3);
        }

        .ts-applications-page .status.s-shortlisted {
            color: var(--app-teal);
            background: rgba(0, 245, 196, .09);
            border-color: rgba(0, 245, 196, .27);
        }

        .ts-applications-page .status.s-interview {
            color: #ffb86b;
            background: rgba(255, 174, 87, .1);
            border-color: rgba(255, 174, 87, .3);
        }

        .ts-applications-page .status.s-selected {
            color: #70ff9b;
            background: rgba(54, 255, 140, .09);
            border-color: rgba(54, 255, 140, .28);
        }

        .ts-applications-page .status.s-rejected {
            color: #ff83c8;
            background: rgba(255, 69, 212, .09);
            border-color: rgba(255, 69, 212, .27);
        }

        /* Empty state */

        .ts-applications-page .empty {
            padding: 45px 20px;
            text-align: center;
            color: var(--app-muted);
            line-height: 2;
        }

        .ts-applications-page .empty a {
            color: var(--app-cyan) !important;
            font-weight: 750;
            text-decoration: none;
            transition: color .2s ease;
        }

        .ts-applications-page .empty a:hover {
            color: var(--app-teal) !important;
            text-decoration: underline;
        }

        @media (max-width: 700px) {
            .ts-applications-page {
                padding: 25px 14px 45px;
            }

            .ts-applications-page .page-heading {
                padding: 23px;
            }

            .ts-applications-page .table-card {
                padding: 5px;
            }

            .ts-applications-page table {
                min-width: 620px;
            }

            .ts-applications-page th,
            .ts-applications-page td {
                padding: 15px 13px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            .ts-applications-page *,
            .ts-app-space * {
                animation: none !important;
                transition: none !important;
            }
        }
    </style>
</head>

<body>

<?php include 'student_nav.php'; ?>

<div class="ts-app-space" aria-hidden="true">
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>
    <span class="shooting-star"></span>
    <span class="shooting-star"></span>
</div>

<main class="dashboard ts-applications-page">

    <div class="page-heading">
        <div>
            <p class="eyebrow">✦ APPLICATION TRACKER</p>

            <h1>My applications</h1>

            <p>
                Keep an eye on every opportunity you applied for.
            </p>
        </div>
    </div>

    <div class="table-card">
        <table>
            <thead>
                <tr>
                    <th>Internship</th>
                    <th>Company</th>
                    <th>Applied</th>
                    <th>Status</th>
                </tr>
            </thead>

            <tbody>
                <?php if (!$rows): ?>

                    <tr>
                        <td colspan="4" class="empty">
                            No applications yet.
                            <a href="internships.php">
                                Browse internships →
                            </a>
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td>
                                <strong><?= e($r['title']) ?></strong>
                            </td>

                            <td>
                                <?= e($r['company_name']) ?>
                            </td>

                            <td>
                                <?= e(date('d M Y', strtotime($r['applied_at']))) ?>
                            </td>

                            <td>
                                <span class="status <?= e(status_class($r['status'])) ?>">
                                    <?= e($r['status']) ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                <?php endif; ?>
            </tbody>
        </table>
    </div>

</main>

</body>
</html>