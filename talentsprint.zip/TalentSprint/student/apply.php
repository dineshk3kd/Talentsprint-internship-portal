<?php
session_start();

require_once __DIR__ . '/../config/database.php';

require_role('student');

$data = db_load();

$id = (int) ($_GET['id'] ?? 0);
$internship = db_internship($data, $id);

$message = '';
$messageType = 'success';

$student = db_student_by_user(
    $data,
    (int) $_SESSION['user_id']
);

$sid = (int) ($student['id'] ?? 0);
$already = false;

if ($internship && $internship['status'] === 'Open') {

    foreach ($data['applications'] as $a) {
        if (
            (int) $a['student_id'] === $sid &&
            (int) $a['internship_id'] === $id
        ) {
            $already = true;
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$already) {

        $data['applications'][] = [
            'id' => db_next_id($data, 'applications'),
            'student_id' => $sid,
            'internship_id' => $id,
            'status' => 'Applied',
            'applied_at' => db_now()
        ];

        if (db_save($data)) {
            $message = 'Application submitted successfully.';
        } else {
            $message = 'Could not save your application.';
            $messageType = 'error';
        }

    } elseif ($already) {
        $message = 'You already applied for this internship.';
        $messageType = 'error';
    }
}

$company = $internship
    ? db_company($data, (int) $internship['company_id'])
    : null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Apply · TalentSprint</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>
        /* Galaxy styling is scoped to this page only. */

        body:has(.ts-apply-page) {
            --galaxy-bg: #07091b;
            --galaxy-panel: rgba(18, 23, 59, .91);
            --galaxy-cyan: #00e5ff;
            --galaxy-teal: #00f5c4;
            --galaxy-blue: #477bff;
            --galaxy-purple: #a855f7;
            --galaxy-pink: #ff45d4;
            --galaxy-orange: #ffae57;
            --galaxy-text: #f8faff;
            --galaxy-muted: #b4bfdc;

            min-height: 100vh;
            color: var(--galaxy-text);

            background:
                radial-gradient(
                    ellipse at 12% 15%,
                    rgba(71, 123, 255, .2),
                    transparent 34%
                ),
                radial-gradient(
                    ellipse at 88% 28%,
                    rgba(168, 85, 247, .17),
                    transparent 35%
                ),
                radial-gradient(
                    ellipse at 50% 100%,
                    rgba(0, 245, 196, .08),
                    transparent 40%
                ),
                var(--galaxy-bg);

            overflow-x: hidden;
        }

        .ts-apply-page {
            position: relative;
            isolation: isolate;
            max-width: 1000px;
            margin: 0 auto;
            padding: 48px 25px 75px;
        }

        /* Galaxy background */

        .ts-galaxy {
            position: fixed;
            inset: 0;
            z-index: -1;
            overflow: hidden;
            pointer-events: none;
        }

        .ts-galaxy .star {
            position: absolute;
            width: 3px;
            height: 3px;
            border-radius: 50%;
            background: #fff;
            box-shadow: 0 0 9px var(--galaxy-cyan);
            animation: galaxy-twinkle 3s ease-in-out infinite alternate;
        }

        .ts-galaxy .star:nth-child(1) {
            top: 12%;
            left: 14%;
        }

        .ts-galaxy .star:nth-child(2) {
            top: 28%;
            left: 83%;
            animation-delay: .8s;
        }

        .ts-galaxy .star:nth-child(3) {
            top: 63%;
            left: 10%;
            animation-delay: 1.4s;
        }

        .ts-galaxy .star:nth-child(4) {
            top: 80%;
            left: 76%;
            animation-delay: 2s;
        }

        .ts-galaxy .star:nth-child(5) {
            top: 45%;
            left: 53%;
            animation-delay: .5s;
        }

        .ts-galaxy .star:nth-child(6) {
            top: 90%;
            left: 42%;
            animation-delay: 1.8s;
        }

        .ts-galaxy .shooting-star {
            position: absolute;
            top: 15%;
            left: 110%;
            width: 130px;
            height: 2px;
            opacity: 0;
            transform: rotate(-35deg);

            background: linear-gradient(
                90deg,
                transparent,
                var(--galaxy-cyan),
                white
            );

            filter: drop-shadow(0 0 5px var(--galaxy-cyan));
            animation: galaxy-shoot 10s linear infinite;
        }

        .ts-galaxy .shooting-star:nth-child(8) {
            top: 55%;
            animation-delay: 4s;
            animation-duration: 12s;
        }

        .ts-galaxy .shooting-star:nth-child(9) {
            top: 75%;
            animation-delay: 7s;
            animation-duration: 11s;
        }

        @keyframes galaxy-twinkle {
            from {
                opacity: .25;
                transform: scale(.7);
            }

            to {
                opacity: 1;
                transform: scale(1.5);
            }
        }

        @keyframes galaxy-shoot {
            0% {
                left: 110%;
                opacity: 0;
            }

            5% {
                opacity: 1;
            }

            20% {
                left: -25%;
                opacity: 0;
            }

            100% {
                left: -25%;
                opacity: 0;
            }
        }

        /* Decorative glowing galaxy orb */

        .ts-galaxy-orb {
            position: absolute;
            top: 65px;
            right: 48px;
            width: 90px;
            height: 90px;
            border-radius: 50%;

            background: radial-gradient(
                circle at 35% 30%,
                #f6f2ff 0,
                #bca4ff 10%,
                #8253ef 27%,
                #392c9c 52%,
                #10183e 72%
            );

            box-shadow:
                0 0 20px rgba(168, 85, 247, .55),
                0 0 50px rgba(71, 123, 255, .2),
                inset -12px -8px 18px rgba(0, 0, 30, .65);

            animation: galaxy-float 5s ease-in-out infinite;
        }

        .ts-galaxy-orb::before {
            content: "";
            position: absolute;
            top: 31px;
            left: -13px;
            width: 115px;
            height: 25px;
            border: 2px solid rgba(0, 229, 255, .7);
            border-radius: 50%;
            transform: rotate(-24deg);
            box-shadow: 0 0 10px rgba(0, 229, 255, .25);
        }

        .ts-galaxy-orb::after {
            content: "";
            position: absolute;
            top: 13px;
            left: 67px;
            width: 9px;
            height: 9px;
            border-radius: 50%;
            background: var(--galaxy-teal);
            box-shadow: 0 0 12px var(--galaxy-teal);
        }

        @keyframes galaxy-float {
            0%, 100% {
                transform: translateY(0) rotate(0);
            }

            50% {
                transform: translateY(-8px) rotate(5deg);
            }
        }

        /* Internship details card */

        .ts-apply-page .detail-card {
            position: relative;
            padding: 38px;
            border: 1px solid rgba(133, 156, 255, .25);
            border-radius: 26px;
            background:
                linear-gradient(
                    135deg,
                    rgba(71, 123, 255, .11),
                    rgba(168, 85, 247, .08),
                    rgba(0, 245, 196, .035)
                ),
                var(--galaxy-panel);

            box-shadow:
                0 25px 75px rgba(0, 0, 0, .25),
                0 0 35px rgba(71, 123, 255, .06);

            overflow: hidden;
            animation: galaxy-card-enter .7s ease both;
        }

        .ts-apply-page .detail-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;

            background: linear-gradient(
                90deg,
                var(--galaxy-cyan),
                var(--galaxy-blue),
                var(--galaxy-purple),
                var(--galaxy-pink),
                var(--galaxy-teal)
            );

            background-size: 200% auto;
            animation: galaxy-border 6s linear infinite;
        }

        @keyframes galaxy-border {
            to {
                background-position: 200% center;
            }
        }

        @keyframes galaxy-card-enter {
            from {
                opacity: 0;
                transform: translateY(18px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Open status badge */

        .ts-apply-page .status.open {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 14px;
            margin-bottom: 18px;
            border-radius: 30px;

            color: var(--galaxy-teal);
            background: rgba(0, 245, 196, .09);
            border: 1px solid rgba(0, 245, 196, .3);

            font-size: 12px;
            font-weight: 800;
            letter-spacing: .8px;
        }

        .ts-apply-page .status.open::before {
            content: "";
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: var(--galaxy-teal);
            box-shadow: 0 0 10px var(--galaxy-teal);
            animation: galaxy-pulse 1.8s ease-in-out infinite;
        }

        @keyframes galaxy-pulse {
            0%, 100% {
                opacity: 1;
                transform: scale(1);
            }

            50% {
                opacity: .45;
                transform: scale(.75);
            }
        }

        .ts-apply-page .detail-card h1 {
            position: relative;
            z-index: 1;
            max-width: 75%;
            margin: 0 0 12px;

            font-size: clamp(29px, 4vw, 43px);
            line-height: 1.2;
            font-weight: 850;
            overflow-wrap: anywhere;

            background: linear-gradient(
                90deg,
                #fff,
                var(--galaxy-cyan),
                #c7b4ff,
                var(--galaxy-pink)
            );

            background-size: 220% auto;
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;

            animation: galaxy-title 7s linear infinite;
        }

        @keyframes galaxy-title {
            to {
                background-position: 220% center;
            }
        }

        .ts-apply-page .detail-card h3 {
            margin: 0 0 24px;
            color: var(--galaxy-teal);
            font-size: 18px;
            font-weight: 700;
        }

        .ts-apply-page .detail-card > p {
            color: var(--galaxy-muted);
            font-size: 15px;
            line-height: 1.9;
            overflow-wrap: anywhere;
        }

        /* Internship information grid */

        .ts-apply-page .detail-info {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 15px;
            margin: 30px 0;
        }

        .ts-apply-page .detail-info p {
            margin: 0;
            padding: 17px 18px;
            border-radius: 14px;
            border: 1px solid rgba(133, 156, 255, .16);
            background: rgba(7, 9, 27, .48);

            color: var(--galaxy-muted);
            font-size: 14px;
            line-height: 1.7;

            transition:
                transform .25s ease,
                border-color .25s ease,
                background .25s ease;
        }

        .ts-apply-page .detail-info p:hover {
            transform: translateY(-3px);
            border-color: rgba(0, 229, 255, .4);
            background: rgba(71, 123, 255, .08);
        }

        .ts-apply-page .detail-info strong {
            color: var(--galaxy-cyan);
        }

        /* Application alerts */

        .ts-apply-page .alert {
            position: relative;
            padding: 16px 18px;
            margin: 20px 0;
            border-radius: 13px;
            background: rgba(7, 9, 27, .5);
            color: var(--galaxy-text);
            line-height: 1.7;
        }

        .ts-apply-page .alert.success {
            border: 1px solid rgba(0, 245, 196, .42);
            box-shadow: inset 3px 0 0 var(--galaxy-teal);
        }

        .ts-apply-page .alert.error {
            border: 1px solid rgba(255, 69, 212, .4);
            box-shadow: inset 3px 0 0 var(--galaxy-pink);
        }

        /* Apply button */

        .ts-apply-page .btn.primary {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;

            padding: 15px 27px;
            margin-top: 8px;
            border: 0;
            border-radius: 13px;

            color: #071522;
            background: linear-gradient(
                100deg,
                var(--galaxy-teal),
                var(--galaxy-cyan),
                #9ba7ff
            );

            font-size: 15px;
            font-weight: 850;
            text-decoration: none;

            box-shadow: 0 0 25px rgba(0, 229, 255, .15);
            cursor: pointer;

            transition:
                transform .25s ease,
                box-shadow .25s ease;
        }

        .ts-apply-page .btn.primary::after {
            content: "→";
            font-size: 20px;
            transition: transform .25s ease;
        }

        .ts-apply-page .btn.primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 0 32px rgba(0, 229, 255, .35);
        }

        .ts-apply-page .btn.primary:hover::after {
            transform: translateX(4px);
        }

        /* Missing internship message */

        .ts-apply-page > .alert.error {
            padding: 22px;
            border-radius: 16px;
            background: var(--galaxy-panel);
        }

        @media (max-width: 700px) {
            .ts-apply-page {
                padding: 25px 15px 45px;
            }

            .ts-apply-page .detail-card {
                padding: 25px 20px;
            }

            .ts-apply-page .detail-card h1 {
                max-width: 100%;
            }

            .ts-galaxy-orb {
                position: relative;
                top: auto;
                right: auto;
                width: 60px;
                height: 60px;
                margin: 0 0 22px 12px;
            }

            .ts-galaxy-orb::before {
                top: 20px;
                left: -9px;
                width: 76px;
                height: 17px;
            }

            .ts-galaxy-orb::after {
                top: 7px;
                left: 44px;
                width: 7px;
                height: 7px;
            }

            .ts-apply-page .detail-info {
                grid-template-columns: 1fr;
                gap: 11px;
                margin: 24px 0;
            }

            .ts-apply-page .btn.primary {
                width: 100%;
                box-sizing: border-box;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            .ts-apply-page *,
            .ts-galaxy * {
                animation: none !important;
                transition: none !important;
            }
        }
    </style>
</head>

<body>

<?php include 'student_nav.php'; ?>

<div class="ts-galaxy" aria-hidden="true">
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>
    <span class="star"></span>

    <span class="shooting-star"></span>
    <span class="shooting-star"></span>
    <span class="shooting-star"></span>
</div>

<main class="dashboard narrow ts-apply-page">

    <?php if (!$internship || !$company): ?>

        <div class="alert error">
            Internship not found.
        </div>

    <?php else: ?>

        <div class="detail-card">

            <div class="ts-galaxy-orb" aria-hidden="true"></div>

            <span class="status open">Open</span>

            <h1><?= e($internship['title']) ?></h1>

            <h3><?= e($company['company_name']) ?></h3>

            <p>
                <?= nl2br(e($internship['description'])) ?>
            </p>

            <div class="detail-info">

                <p>
                    <strong>Location:</strong><br>
                    <?= e($internship['location']) ?>
                </p>

                <p>
                    <strong>Skills:</strong><br>
                    <?= e($internship['skills'] ?: 'Not specified') ?>
                </p>

                <p>
                    <strong>Duration:</strong><br>
                    <?= e($internship['duration'] ?: 'Not specified') ?>
                </p>

                <p>
                    <strong>Stipend:</strong><br>
                    <?= e($internship['stipend'] ?: 'Not specified') ?>
                </p>

            </div>

            <?php if ($message): ?>
                <div class="alert <?= $messageType === 'success' ? 'success' : 'error' ?>">
                    <?= e($message) ?>
                </div>
            <?php endif; ?>

            <?php if (!$already && $message === ''): ?>
                <form method="POST">
                    <button class="btn primary" type="submit">
                        Apply now
                    </button>
                </form>
            <?php endif; ?>

        </div>

    <?php endif; ?>

</main>

</body>
</html>