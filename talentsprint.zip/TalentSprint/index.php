<?php
session_start();

require_once __DIR__ . '/config/database.php';

$data = db_load();

$openCount = count(array_filter(
    $data['internships'],
    fn($i) => ($i['status'] ?? 'Open') === 'Open'
));

$companyCount = count($data['companies']);
$studentCount = count($data['students']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>TalentSprint | Launch Your Career</title>

    <link rel="stylesheet" href="css/style.css">

    <style>
        :root {
            --bg: #07091b;
            --panel: rgba(18, 23, 59, .88);
            --cyan: #00e5ff;
            --teal: #00f5c4;
            --blue: #477bff;
            --purple: #a855f7;
            --pink: #ff45d4;
            --orange: #ffae57;
            --text: #f8faff;
            --muted: #b4bfdc;
        }

        * {
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            margin: 0;
            overflow-x: hidden;
            background: var(--bg);
            color: var(--text);
            font-family: Inter, "Segoe UI", Arial, sans-serif;
        }

        a {
            text-decoration: none;
        }

        /* NAVIGATION */

        .navbar {
            position: sticky;
            top: 0;
            z-index: 1000;
            min-height: 82px;
            padding: 15px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            background: rgba(5, 8, 26, .94);
            border-bottom: 1px solid rgba(255,255,255,.09);
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
        }

        .logo {
            color: white;
            font-size: 27px;
            font-weight: 900;
            letter-spacing: -1.2px;
        }

        .logo span {
            background: linear-gradient(
                90deg,
                var(--cyan),
                var(--blue),
                var(--purple),
                var(--pink)
            );
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .nav-links a {
            color: var(--muted);
            font-size: 14px;
            font-weight: 700;
            transition: color .2s ease;
        }

        .nav-links a:hover {
            color: var(--cyan);
        }

        .nav-links .nav-button {
            padding: 13px 23px;
            border-radius: 13px;
            color: white !important;
            background: linear-gradient(
                110deg,
                var(--cyan),
                var(--blue),
                var(--purple)
            );
            box-shadow: 0 8px 28px rgba(79,125,255,.28);
            transition: transform .25s ease, box-shadow .25s ease;
        }

        .nav-links .nav-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(168,85,247,.38);
        }

        /* HERO */

        .hero {
            min-height: 680px;
            padding: 70px 5%;
            display: grid;
            grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
            align-items: center;
            gap: 48px;
            position: relative;
            isolation: isolate;
            background:
                radial-gradient(
                    circle at 5% 5%,
                    rgba(0,229,255,.12),
                    transparent 30%
                ),
                radial-gradient(
                    circle at 85% 20%,
                    rgba(168,85,247,.2),
                    transparent 32%
                ),
                radial-gradient(
                    circle at 90% 90%,
                    rgba(255,69,212,.13),
                    transparent 35%
                ),
                linear-gradient(135deg,#0b1230,#07091b 65%,#130b2d);
        }

        .hero-content,
        .hero-visual {
            min-width: 0;
            position: relative;
            z-index: 1;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 22px;
            padding: 9px 15px;
            border: 1px solid rgba(0,245,196,.35);
            border-radius: 30px;
            background: rgba(0,245,196,.07);
            color: var(--teal);
            font-size: 11px;
            font-weight: 900;
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        .hero h1 {
            margin: 0 0 22px;
            font-size: clamp(44px, 5vw, 72px);
            line-height: 1.06;
            letter-spacing: -3px;
            font-weight: 950;
        }

        .gradient-text {
            display: inline-block;
            background: linear-gradient(
                90deg,
                var(--teal),
                var(--cyan),
                #8a8aff,
                var(--pink),
                var(--orange)
            );
            background-size: 200% auto;
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: gradientFlow 7s ease-in-out infinite alternate;
        }

        @keyframes gradientFlow {
            from { background-position: 0% center; }
            to { background-position: 100% center; }
        }

        .hero-text {
            max-width: 560px;
            margin: 0 0 30px;
            color: var(--muted);
            font-size: 16px;
            line-height: 1.9;
        }

        /* SEARCH */

        .hero-search {
            width: 100%;
            max-width: 530px;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 7px;
            margin-bottom: 22px;
            border: 1px solid rgba(0,229,255,.55);
            border-radius: 40px;
            background: rgba(17,23,58,.88);
            box-shadow:
                0 0 25px rgba(0,229,255,.08),
                inset 0 0 20px rgba(79,125,255,.06);
        }

        .hero-search input {
            flex: 1;
            min-width: 0;
            padding: 13px 12px;
            border: none;
            outline: none;
            background: transparent;
            color: white;
            font-size: 14px;
        }

        .hero-search input::placeholder {
            color: #9ba9ce;
        }

        .hero-search button {
            flex-shrink: 0;
            padding: 13px 25px;
            border: none;
            border-radius: 30px;
            background: linear-gradient(
                110deg,
                var(--teal),
                var(--cyan),
                var(--purple)
            );
            color: #071024;
            font-weight: 900;
            cursor: pointer;
            transition: transform .2s ease;
        }

        .hero-search button:hover {
            transform: scale(1.04);
        }

        .quick-tags {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 9px;
            color: var(--muted);
            font-size: 13px;
        }

        .quick-tags strong {
            color: white;
            margin-right: 4px;
        }

        .tag {
            padding: 7px 14px;
            border: 1px solid rgba(255,255,255,.14);
            border-radius: 25px;
            background: rgba(255,255,255,.04);
            color: #dce4ff;
            transition: all .2s ease;
        }

        .tag:nth-of-type(1):hover {
            border-color: var(--cyan);
            color: var(--cyan);
        }

        .tag:nth-of-type(2):hover {
            border-color: var(--purple);
            color: #d6a8ff;
        }

        .tag:nth-of-type(3):hover {
            border-color: var(--pink);
            color: var(--pink);
        }

        .tag:nth-of-type(4):hover {
            border-color: var(--orange);
            color: var(--orange);
        }

        /* RIGHT-SIDE VISUAL */

        .hero-visual {
            min-height: 470px;
            display: flex;
            align-items: center;
            justify-content: center;
            isolation: isolate;
        }

        .visual-glow {
            position: absolute;
            width: 75%;
            height: 70%;
            border-radius: 50%;
            background: linear-gradient(
                135deg,
                rgba(0,229,255,.2),
                rgba(168,85,247,.25),
                rgba(255,69,212,.12)
            );
            filter: blur(75px);
            z-index: -1;
        }

        .visual-layout {
            position: relative;
            width: 100%;
            max-width: 590px;
        }

        /* FEATURED INTERNSHIP */

        .internship-preview {
            position: relative;
            z-index: 2;
            padding: 25px;
            border: 1px solid rgba(0,229,255,.5);
            border-radius: 24px;
            background: linear-gradient(
                140deg,
                rgba(20,29,76,.97),
                rgba(12,13,43,.97)
            );
            box-shadow:
                0 25px 70px rgba(0,0,0,.4),
                0 0 35px rgba(0,194,255,.12);
            transform: rotate(-2deg);
            transition: transform .35s ease, box-shadow .35s ease;
        }

        .internship-preview:hover {
            transform: rotate(0deg) translateY(-5px);
            box-shadow:
                0 30px 80px rgba(0,0,0,.45),
                0 0 40px rgba(168,85,247,.2);
        }

        .opportunity-label {
            position: absolute;
            top: -17px;
            right: 24px;
            padding: 8px 16px;
            border: 1px solid rgba(255,69,212,.55);
            border-radius: 25px;
            background: linear-gradient(110deg,#6b21a8,#be185d);
            color: white;
            font-size: 12px;
            font-weight: 850;
            box-shadow: 0 6px 20px rgba(255,69,212,.2);
        }

        .internship-top {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 20px;
        }

        .company-logo {
            width: 65px;
            height: 65px;
            flex-shrink: 0;
            display: grid;
            place-items: center;
            border: 1px solid rgba(255,255,255,.2);
            border-radius: 18px;
            background: linear-gradient(135deg,#ffffff,#dbeafe);
            color: #2563eb;
            font-size: 30px;
            font-weight: 950;
            box-shadow: 0 8px 25px rgba(0,0,0,.2);
        }

        .internship-info {
            min-width: 0;
        }

        .internship-info h2 {
            margin: 0 0 7px;
            color: white;
            font-size: clamp(17px,2vw,22px);
            line-height: 1.35;
        }

        .internship-info p {
            margin: 0;
            color: var(--muted);
            font-size: 14px;
        }

        .internship-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 12px 18px;
            margin: 18px 0;
            color: #d8e0ff;
            font-size: 13px;
        }

        .internship-bottom {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 14px;
        }

        .match-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 9px 12px;
            border: 1px solid rgba(0,245,196,.3);
            border-radius: 25px;
            background: rgba(0,245,196,.12);
            color: var(--teal);
            font-size: 12px;
            font-weight: 900;
        }

        .preview-apply {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 18px;
            border-radius: 25px;
            background: linear-gradient(
                110deg,
                var(--cyan),
                var(--blue),
                var(--purple)
            );
            color: white;
            font-size: 13px;
            font-weight: 900;
            box-shadow: 0 8px 25px rgba(79,125,255,.25);
            transition: transform .2s ease;
        }

        .preview-apply:hover {
            transform: translateY(-2px);
        }

        /* Decorative career illustration */

        .career-art {
            position: relative;
            min-height: 205px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 10px;
        }

        .books {
            position: relative;
            width: 45%;
            height: 165px;
        }

        .book {
            position: absolute;
            left: 0;
            width: 100%;
            height: 32px;
            border-radius: 7px;
            transform: skewY(-7deg);
            box-shadow: 0 8px 15px rgba(0,0,0,.28);
        }

        .book::after {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            width: 12px;
            height: 100%;
            border-radius: 0 7px 7px 0;
            background: rgba(255,255,255,.2);
        }

        .book-one {
            bottom: 12px;
            background: linear-gradient(90deg,#f97316,#ffb454);
        }

        .book-two {
            bottom: 47px;
            background: linear-gradient(90deg,#8b5cf6,#c084fc);
        }

        .book-three {
            bottom: 82px;
            background: linear-gradient(90deg,#0891b2,#22d3ee);
        }

        .graduation-cap {
            position: absolute;
            left: 15%;
            top: 0;
            width: 70%;
            height: 42px;
            background: linear-gradient(135deg,#4f46e5,#a855f7);
            clip-path: polygon(50% 0,100% 40%,50% 80%,0 40%);
            filter: drop-shadow(0 5px 10px rgba(168,85,247,.45));
        }

        .graduation-cap::after {
            content: '';
            position: absolute;
            width: 4px;
            height: 28px;
            right: 18%;
            top: 19px;
            background: var(--orange);
            transform: rotate(25deg);
        }

        .growth-panel {
            width: 48%;
            height: 150px;
            padding: 17px;
            border: 1px solid rgba(0,229,255,.3);
            border-radius: 18px;
            background: linear-gradient(
                145deg,
                rgba(12,30,76,.96),
                rgba(22,12,64,.96)
            );
            box-shadow: 0 10px 35px rgba(79,125,255,.2);
            transform: rotate(3deg);
        }

        .growth-panel-title {
            color: var(--muted);
            font-size: 11px;
            font-weight: 700;
        }

        .chart {
            height: 82px;
            display: flex;
            align-items: flex-end;
            justify-content: center;
            gap: 9px;
            padding-top: 10px;
        }

        .chart span {
            flex: 1;
            max-width: 28px;
            border-radius: 5px 5px 0 0;
            background: linear-gradient(180deg,var(--cyan),var(--purple));
            box-shadow: 0 0 12px rgba(0,229,255,.12);
            animation: barRise 1.2s ease both;
        }

        .chart span:nth-child(1) { height: 25%; }
        .chart span:nth-child(2) { height: 42%; }
        .chart span:nth-child(3) { height: 58%; }
        .chart span:nth-child(4) { height: 78%; }
        .chart span:nth-child(5) { height: 100%; }

        @keyframes barRise {
            from { height: 0; opacity: .2; }
            to { opacity: 1; }
        }

        /* LIVE STATISTICS */

        .stats-panel {
            position: absolute;
            right: -5px;
            bottom: -8px;
            z-index: 3;
            width: 225px;
            padding: 17px;
            border: 1px solid rgba(168,85,247,.55);
            border-radius: 21px;
            background: rgba(15,16,54,.96);
            box-shadow: 0 15px 40px rgba(0,0,0,.3);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
        }

        .stats-panel h3 {
            margin: 0 0 10px;
            font-size: 14px;
        }

        .stat-row {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 9px 0;
            border-top: 1px solid rgba(255,255,255,.08);
        }

        .stat-icon {
            width: 35px;
            height: 35px;
            flex-shrink: 0;
            display: grid;
            place-items: center;
            border-radius: 10px;
            background: rgba(79,125,255,.17);
            font-size: 17px;
        }

        .stat-number {
            display: block;
            font-size: 20px;
            line-height: 1.2;
            font-weight: 950;
        }

        .stat-row:nth-of-type(1) .stat-number {
            color: var(--teal);
        }

        .stat-row:nth-of-type(2) .stat-number {
            color: var(--cyan);
        }

        .stat-row:nth-of-type(3) .stat-number {
            color: #c084fc;
        }

        .stat-label {
            display: block;
            margin-top: 2px;
            color: var(--muted);
            font-size: 11px;
        }

        .career-tagline {
            display: flex;
            align-items: center;
            gap: 12px;
            width: fit-content;
            max-width: 100%;
            margin-top: 20px;
            padding: 13px 18px;
            border: 1px solid rgba(255,69,212,.3);
            border-radius: 15px;
            background: rgba(20,15,53,.9);
            box-shadow: 0 10px 25px rgba(0,0,0,.2);
        }

        .career-tagline-icon {
            color: var(--teal);
            font-size: 25px;
        }

        .career-tagline strong {
            display: block;
            color: var(--orange);
            font-size: 13px;
        }

        .career-tagline small {
            display: block;
            margin-top: 4px;
            color: var(--muted);
            font-size: 11px;
        }

        /* FEATURES */

        .section {
            padding: 95px 5%;
            background:
                radial-gradient(
                    circle at 0% 50%,
                    rgba(168,85,247,.07),
                    transparent 28%
                ),
                radial-gradient(
                    circle at 100% 50%,
                    rgba(0,229,255,.06),
                    transparent 28%
                ),
                var(--bg);
        }

        .section-title {
            margin-bottom: 50px;
            text-align: center;
        }

        .section-title h2 {
            margin: 10px 0 0;
            font-size: clamp(30px,4vw,45px);
            letter-spacing: -1.4px;
            background: linear-gradient(90deg,#fff,#c4b5fd,#7dd3fc,#fff);
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .feature-grid {
            display: grid;
            grid-template-columns: repeat(4,minmax(0,1fr));
            gap: 22px;
        }

        .feature-card {
            padding: 30px 24px;
            border: 1px solid rgba(255,255,255,.09);
            border-top: 2px solid var(--accent);
            border-radius: 22px;
            background: var(--panel);
            transition: transform .3s ease, box-shadow .3s ease;
        }

        .feature-card:nth-child(1) { --accent: var(--teal); }
        .feature-card:nth-child(2) { --accent: var(--blue); }
        .feature-card:nth-child(3) { --accent: var(--pink); }
        .feature-card:nth-child(4) { --accent: var(--orange); }

        .feature-card:hover {
            transform: translateY(-7px);
            box-shadow: 0 18px 38px rgba(0,0,0,.25);
        }

        .feature-icon {
            width: 55px;
            height: 55px;
            display: grid;
            place-items: center;
            margin-bottom: 22px;
            border: 1px solid color-mix(in srgb, var(--accent) 35%, transparent);
            border-radius: 16px;
            background: color-mix(in srgb, var(--accent) 12%, transparent);
            font-size: 24px;
        }

        .feature-card h3 {
            margin: 0 0 12px;
            color: white;
            font-size: 18px;
        }

        .feature-card p {
            margin: 0;
            color: var(--muted);
            font-size: 14px;
            line-height: 1.8;
        }

        /* CALL TO ACTION */

        .cta {
            margin: 0 5% 80px;
            padding: 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;
            border: 1px solid rgba(168,85,247,.4);
            border-radius: 26px;
            background: linear-gradient(
                120deg,
                rgba(0,229,255,.07),
                rgba(168,85,247,.13),
                rgba(255,69,212,.07)
            );
        }

        .cta h2 {
            margin: 0 0 10px;
            font-size: clamp(24px,3vw,34px);
        }

        .cta p {
            margin: 0;
            color: var(--muted);
            line-height: 1.7;
        }

        .btn-primary {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 15px 26px;
            border-radius: 30px;
            background: linear-gradient(
                110deg,
                var(--pink),
                var(--purple),
                var(--blue)
            );
            color: white;
            font-size: 14px;
            font-weight: 900;
            white-space: nowrap;
            transition: transform .2s ease;
        }

        .btn-primary:hover {
            transform: translateY(-3px);
        }

        footer {
            padding: 30px 5%;
            border-top: 1px solid rgba(255,255,255,.08);
            background: #050616;
            color: #8e9ab8;
            text-align: center;
            font-size: 13px;
        }

        /* RESPONSIVE */

        @media (max-width: 1100px) {
            .hero {
                grid-template-columns: minmax(0,1fr) minmax(0,1fr);
                gap: 30px;
                padding: 60px 4%;
            }

            .hero h1 {
                font-size: clamp(42px,5vw,60px);
            }

            .stats-panel {
                right: 0;
                width: 190px;
            }

            .career-art {
                padding-right: 45px;
            }
        }

        @media (max-width: 850px) {
            .hero {
                grid-template-columns: 1fr;
                gap: 45px;
                padding: 55px 6%;
            }

            .hero-content {
                max-width: 700px;
            }

            .hero-visual {
                width: 100%;
                max-width: 650px;
                margin: 0 auto;
            }

            .visual-layout {
                max-width: 590px;
            }

            .feature-grid {
                grid-template-columns: repeat(2,minmax(0,1fr));
            }
        }

        @media (max-width: 600px) {
            .navbar {
                align-items: flex-start;
                flex-direction: column;
                gap: 15px;
            }

            .logo {
                font-size: 24px;
            }

            .nav-links {
                width: 100%;
                gap: 17px;
                flex-wrap: wrap;
            }

            .nav-links a {
                font-size: 12px;
            }

            .nav-links .nav-button {
                padding: 10px 13px;
            }

            .hero {
                padding: 45px 5%;
            }

            .hero h1 {
                font-size: clamp(40px,10vw,56px);
                letter-spacing: -1.8px;
            }

            .hero-text {
                font-size: 15px;
            }

            .hero-search {
                border-radius: 20px;
            }

            .hero-search input {
                padding: 12px 5px;
                font-size: 12px;
            }

            .hero-search button {
                padding: 12px 16px;
            }

            .hero-visual {
                min-height: 390px;
            }

            .internship-preview {
                padding: 20px 16px;
            }

            .internship-top {
                gap: 12px;
            }

            .company-logo {
                width: 50px;
                height: 50px;
                font-size: 24px;
            }

            .internship-meta {
                font-size: 11px;
                gap: 9px;
            }

            .career-art {
                min-height: 150px;
                padding-right: 0;
            }

            .books {
                height: 130px;
            }

            .growth-panel {
                height: 120px;
                padding: 12px;
            }

            .chart {
                height: 65px;
            }

            .stats-panel {
                right: -2px;
                bottom: -35px;
                width: 175px;
                padding: 12px;
            }

            .stats-panel h3 {
                font-size: 12px;
            }

            .stat-number {
                font-size: 17px;
            }

            .stat-icon {
                width: 29px;
                height: 29px;
                font-size: 14px;
            }

            .stat-label {
                font-size: 10px;
            }

            .career-tagline {
                margin-top: 45px;
            }

            .feature-grid {
                grid-template-columns: 1fr;
            }

            .section {
                padding: 65px 5%;
            }

            .cta {
                flex-direction: column;
                align-items: flex-start;
                margin: 0 5% 55px;
                padding: 28px 22px;
            }

            .btn-primary {
                white-space: normal;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            html {
                scroll-behavior: auto;
            }

            *,
            *::before,
            *::after {
                animation: none !important;
                transition: none !important;
            }
        }
    </style>
</head>

<body>

<nav class="navbar">
    <a class="logo" href="index.php">Talent<span>Sprint</span></a>

    <div class="nav-links">
        <a href="index.php">Home</a>

        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="<?= $_SESSION['role'] === 'student' ? 'student/dashboard.php' : 'company/dashboard.php' ?>">
                Dashboard
            </a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Sign in</a>
            <a class="nav-button" href="register.php">Create account</a>
        <?php endif; ?>
    </div>
</nav>

<main>

    <!-- HERO SECTION -->
    <section class="hero">

        <div class="hero-content">

            <span class="eyebrow">🚀 Next-Gen Internship Hub</span>

            <h1>
                Learn. Apply.<br>
                <span class="gradient-text">Get noticed.</span>
            </h1>

            <p class="hero-text">
                Discover curated internships, showcase your portfolio, and connect
                directly with top hiring companies ready to invest in your professional
                growth.
            </p>

            <form action="student/dashboard.php" method="GET" class="hero-search">
                <input
                    type="text"
                    name="search"
                    placeholder="Search internships by role, skill, or keyword..."
                    aria-label="Search internships"
                >
                <button type="submit">Explore</button>
            </form>

            <div class="quick-tags">
                <strong>Trending:</strong>
                <a href="#" class="tag">Software</a>
                <a href="#" class="tag">UI/UX</a>
                <a href="#" class="tag">Marketing</a>
                <a href="#" class="tag">Data</a>
            </div>

        </div>

        <!-- NEW RIGHT-SIDE VISUAL -->
        <div class="hero-visual">

            <div class="visual-glow"></div>

            <div class="visual-layout">

                <!-- Featured internship preview -->
                <div class="internship-preview">

                    <div class="opportunity-label">🔥 New Opportunity</div>

                    <div class="internship-top">
                        <div class="company-logo">T</div>

                        <div class="internship-info">
                            <h2>Frontend Developer Intern</h2>
                            <p>Featured Internship · Remote Friendly</p>
                        </div>
                    </div>

                    <div class="internship-meta">
                        <span>📅 6–12 weeks</span>
                        <span>🌐 Remote / Hybrid</span>
                        <span>💼 Internship</span>
                    </div>

                    <div class="internship-bottom">
                        <span class="match-badge">✓ Great Career Match</span>

                        <a class="preview-apply" href="login.php">
                            Explore Roles →
                        </a>
                    </div>

                </div>

                <!-- Career growth illustration -->
                <div class="career-art">

                    <div class="books" aria-hidden="true">
                        <div class="graduation-cap"></div>
                        <div class="book book-one"></div>
                        <div class="book book-two"></div>
                        <div class="book book-three"></div>
                    </div>

                    <div class="growth-panel">
                        <div class="growth-panel-title">YOUR CAREER GROWTH</div>

                        <div class="chart" aria-hidden="true">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>

                </div>

                <!-- Real platform statistics -->
                <div class="stats-panel">
                    <h3>TalentSprint Stats</h3>

                    <div class="stat-row">
                        <div class="stat-icon">💼</div>
                        <div>
                            <span class="stat-number"><?= $openCount ?></span>
                            <span class="stat-label">Open Roles</span>
                        </div>
                    </div>

                    <div class="stat-row">
                        <div class="stat-icon">👥</div>
                        <div>
                            <span class="stat-number"><?= $studentCount ?></span>
                            <span class="stat-label">Active Students</span>
                        </div>
                    </div>

                    <div class="stat-row">
                        <div class="stat-icon">🏢</div>
                        <div>
                            <span class="stat-number"><?= $companyCount ?></span>
                            <span class="stat-label">Hiring Partners</span>
                        </div>
                    </div>
                </div>

                <div class="career-tagline">
                    <div class="career-tagline-icon">↗</div>
                    <div>
                        <strong>Grow. Learn. Succeed.</strong>
                        <small>Your career, our mission.</small>
                    </div>
                </div>

            </div>
        </div>

    </section>

    <!-- FEATURES -->
    <section class="section">

        <div class="section-title">
            <span class="eyebrow">WHY TALENTSPRINT</span>
            <h2>Everything your career journey needs</h2>
        </div>

        <div class="feature-grid">

            <div class="feature-card">
                <div class="feature-icon">👤</div>
                <h3>Build Your Profile</h3>
                <p>
                    Keep your education, skills, bio, and resume ready for every
                    application with ease.
                </p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">🔍</div>
                <h3>Discover Roles</h3>
                <p>
                    Search active internship listings filtered by role, company name,
                    and specific skillsets.
                </p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">📈</div>
                <h3>Track Progress</h3>
                <p>
                    Monitor your application status from submission through review
                    and selection.
                </p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">💼</div>
                <h3>Hire Smarter</h3>
                <p>
                    Companies can publish opportunities and review candidate
                    submissions in one workspace.
                </p>
            </div>

        </div>

    </section>

    <!-- CALL TO ACTION -->
    <?php if (!isset($_SESSION['user_id'])): ?>

        <section class="cta">
            <div>
                <h2>Ready to take the next step?</h2>
                <p>
                    Create your account in seconds and unlock exciting career opportunities.
                </p>
            </div>

            <a class="btn-primary" href="register.php">
                Join TalentSprint →
            </a>
        </section>

    <?php endif; ?>

</main>

<footer>
    &copy; <?= date('Y') ?> TalentSprint &middot; College Internship &amp; Career Portal
</footer>

<script src="js/validation.js"></script>

</body>
</html>